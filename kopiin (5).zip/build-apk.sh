#!/bin/bash
set -e

echo "=========================================="
echo " KOPIIN - Script Build Web App & Android APK"
echo "=========================================="

# 1. Install dependencies
echo ">> [1/5] Memeriksa & Menginstall NPM Dependencies..."
npm install --legacy-peer-deps

# 2. Build Web App
echo ">> [2/5] Membangun Web App Production (Vite Build)..."
npm run build

# 3. Zipping Web Dist
echo ">> [3/5] Mengompresi hasil build web ke dist-kopiin-web.zip..."
zip -r dist-kopiin-web.zip dist/

# 4. Inisialisasi & Sinkronisasi Capacitor Android
echo ">> [4/5] Menyiapkan Capacitor Android..."
if ! command -v npx &> /dev/null; then
    echo "Node/NPX tidak ditemukan. Harap install Node.js."
    exit 1
fi

npm install @capacitor/core@latest @capacitor/cli@latest @capacitor/android@latest --save

if [ ! -d "android" ]; then
    echo ">> Menambahkan platform android..."
    npx cap add android
fi

echo ">> Sinkronisasi aset web ke folder android..."
npx cap sync android

# 5. Build APK dengan Gradle jika Android SDK tersedia
if [ -d "android" ]; then
    echo ">> [5/5] Membangun file APK Android..."
    cd android
    chmod +x gradlew
    ./gradlew assembleDebug
    cd ..
    
    mkdir -p output-apk
    APK_SOURCE=$(find android/app/build/outputs/apk/debug -name "*.apk" | head -n 1)
    if [ -n "$APK_SOURCE" ]; then
        cp "$APK_SOURCE" output-apk/KOPIIN-POS-v1.0.0-debug.apk
        cd output-apk
        zip -r KOPIIN-Android-APK.zip KOPIIN-POS-v1.0.0-debug.apk
        cd ..
        echo "=========================================="
        echo "✅ BERHASIL: APK tersedia di output-apk/KOPIIN-POS-v1.0.0-debug.apk"
        echo "✅ BERHASIL: ZIP APK tersedia di output-apk/KOPIIN-Android-APK.zip"
        echo "✅ BERHASIL: ZIP Web App tersedia di dist-kopiin-web.zip"
        echo "=========================================="
    else
        echo "⚠️ Gradle build selesai, namun APK tidak ditemukan di path default."
    fi
fi
