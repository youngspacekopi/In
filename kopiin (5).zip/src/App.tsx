/**
 * KOPIIN — Main Application Entry
 * Sesuai Permintaan User:
 * 1. Halaman login adalah tampilan awal ketika membuka aplikasi
 * 2. Halaman login TIDAK ADA fitur daftar (hanya login & demo switcher terisolasi)
 * 3. Akses cepat demo switcher HANYA di halaman login, di dalam aplikasi dihilangkan
 * 4. Khusus akun staff, HANYA ADA aplikasi absensi dan laporan absen
 * 5. Fitur login dan logout lengkap
 */

import React, { useState, useCallback } from 'react';
import { PlatformProvider, usePlatform } from './context/PlatformContext';
import { CafeProvider } from './context/CafeContext';
import { LoginPage } from './components/auth/LoginPage';
import { AndroidPresentation } from './components/presentation/AndroidPresentation';
import { ArchitectureOverviewModal } from './components/presentation/ArchitectureOverviewModal';
import { ToastContainer, ToastMessage } from './components/common/Toast';

const KopiinMainApp: React.FC = () => {
  const { isAuthenticated } = usePlatform();
  const [architectureModalOpen, setArchitectureModalOpen] = useState(false);

  // Unified Toast System
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((title: string, type: 'success' | 'info' | 'error' = 'info', description?: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    setToasts((prev) => [...prev, { id, title, type, description }]);
  }, []);

  const dismissToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return (
    <div className="min-h-screen bg-stone-950 text-stone-900 flex flex-col font-sans antialiased selection:bg-amber-500 selection:text-white">
      {/* 
        Kondisi Otentikasi:
        Jika belum login, Halaman Login adalah tampilan awal ketika membuka aplikasi.
        Jika sudah login, masuk ke ruang kerja terisolasi peran masing-masing.
      */}
      {!isAuthenticated ? (
        <LoginPage showToast={showToast} />
      ) : (
        <AndroidPresentation
          onOpenArchitectureModal={() => setArchitectureModalOpen(true)}
          showToast={showToast}
        />
      )}

      {/* System Architecture Specifications Modal */}
      <ArchitectureOverviewModal
        isOpen={architectureModalOpen}
        onClose={() => setArchitectureModalOpen(false)}
      />

      {/* Global Real-time Toast Notifications */}
      <ToastContainer toasts={toasts} onDismiss={dismissToast} />
    </div>
  );
};

export default function App() {
  return (
    <PlatformProvider>
      <CafeProvider>
        <KopiinMainApp />
      </CafeProvider>
    </PlatformProvider>
  );
}
