/**
 * KOPIIN — Dedicated Staff Attendance & Attendance Report Interface
 * Sesuai Permintaan Spesifik:
 * "khusus akun staff, hanya ada aplikasi absensi, dan laporan absen"
 */

import React, { useState, useEffect, useRef } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { StaffAttendance } from '../../types/cafe';
import { 
  Camera, 
  Clock, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  MapPin, 
  LogOut, 
  LogIn, 
  FileSpreadsheet, 
  Filter, 
  Search, 
  Printer, 
  User, 
  RotateCcw, 
  ShieldCheck, 
  X, 
  ChevronRight,
  Eye,
  Sparkles,
  Download
} from 'lucide-react';

interface Props {
  activeTab: 'absensi_app' | 'absensi_laporan';
  onTabChange: (tab: 'absensi_app' | 'absensi_laporan') => void;
  showToast: (text: string, type?: 'success' | 'info' | 'error', description?: string) => void;
}

export const StaffAttendanceView: React.FC<Props> = ({
  activeTab,
  onTabChange,
  showToast,
}) => {
  const { currentUser, activeTenant } = usePlatform();
  const { attendances, recordAttendance, recordCheckOut } = useCafe();

  // Current real-time clock
  const [currentTime, setCurrentTime] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Today string YYYY-MM-DD
  const todayStr = currentTime.toISOString().split('T')[0];

  // Current staff today's attendance record
  const userTodayAttendance = attendances.find(
    (a) => a.user_id === currentUser.id && a.date === todayStr
  );

  // Camera & selfie capture state
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [capturedPhoto, setCapturedPhoto] = useState<string | null>(null);
  const [attendanceNote, setAttendanceNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Check-out modal state
  const [showCheckOutModal, setShowCheckOutModal] = useState(false);
  const [checkOutNote, setCheckOutNote] = useState('Selesai operasional shift');

  // Photo viewer modal
  const [previewPhotoModal, setPreviewPhotoModal] = useState<StaffAttendance | null>(null);

  // Print attendance recap modal
  const [showPrintModal, setShowPrintModal] = useState(false);

  // Filter states for Laporan Absen
  const [reportPeriod, setReportPeriod] = useState<'MONTH' | 'WEEK' | 'ALL'>('MONTH');
  const [filterStatus, setFilterStatus] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Start Camera Stream
  const startCamera = async () => {
    setCameraError(null);
    setIsCameraActive(true);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play().catch(() => {});
        }
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError('Kamera tidak dapat diakses langsung. Anda dapat memilih foto dari kamera/galeri bawaan hp.');
    }
  };

  // Stop Camera Stream
  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach((track) => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  // Capture frame from webcam
  const handleSnapCamera = () => {
    if (videoRef.current) {
      const video = videoRef.current;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 640;
      canvas.height = video.videoHeight || 480;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        setCapturedPhoto(dataUrl);
        stopCamera();
        return;
      }
    }
    handleFallbackSelfie();
  };

  // Fallback demo selfie
  const handleFallbackSelfie = () => {
    const samplePhotos = [
      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&auto=format&fit=crop&q=80',
      'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=500&auto=format&fit=crop&q=80',
    ];
    setCapturedPhoto(samplePhotos[Math.floor(Math.random() * samplePhotos.length)]);
    stopCamera();
  };

  // Handle file select from native mobile camera or gallery
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (uploadEvent) => {
      if (uploadEvent.target?.result) {
        setCapturedPhoto(uploadEvent.target.result as string);
        stopCamera();
      }
    };
    reader.readAsDataURL(file);
  };

  // Submit Check-In
  const handleCheckInSubmit = async () => {
    if (!capturedPhoto) {
      showToast('Wajib Ambil Foto', 'error', 'Silakan ambil foto selfie untuk verifikasi presensi.');
      return;
    }
    setIsSubmitting(true);
    try {
      const att = await recordAttendance({
        photoUrl: capturedPhoto,
        notes: attendanceNote || 'Absensi selfie masuk tepat waktu',
      });
      showToast(
        'Check-In Berhasil!',
        'success',
        `Presensi masuk tercatat pukul ${new Date(att.check_in_time).toLocaleTimeString('id-ID')}`
      );
      setCapturedPhoto(null);
      setAttendanceNote('');
    } catch (err: any) {
      showToast('Gagal Check-In', 'error', err?.message || 'Terjadi kesalahan');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Submit Check-Out
  const handleCheckOutSubmit = () => {
    if (!userTodayAttendance) return;
    try {
      recordCheckOut(userTodayAttendance.id, checkOutNote);
      showToast(
        'Check-Out Berhasil!',
        'success',
        `Presensi pulang tercatat. Terima kasih atas kerja keras Anda hari ini!`
      );
      setShowCheckOutModal(false);
    } catch (err: any) {
      showToast('Gagal Check-Out', 'error', err?.message || 'Terjadi kesalahan');
    }
  };

  // Filter personal attendance history
  const staffAttendances = attendances.filter((a) => {
    // Only show current logged-in staff's attendance records for isolation
    if (a.user_id !== currentUser.id && a.staff_name !== currentUser.full_name) {
      return false;
    }

    // Period filter
    if (reportPeriod === 'WEEK') {
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      if (new Date(a.date) < sevenDaysAgo) return false;
    } else if (reportPeriod === 'MONTH') {
      const currentMonth = todayStr.substring(0, 7);
      if (!a.date.startsWith(currentMonth)) return false;
    }

    // Status filter
    if (filterStatus !== 'ALL') {
      if (filterStatus === 'ON_TIME' && a.status !== 'ON_TIME') return false;
      if (filterStatus === 'LATE' && a.status !== 'LATE') return false;
      if (filterStatus === 'CHECKED_OUT' && a.status !== 'CHECKED_OUT') return false;
    }

    // Search query
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchDate = a.date.includes(q);
      const matchNotes = (a.notes || '').toLowerCase().includes(q);
      if (!matchDate && !matchNotes) return false;
    }

    return true;
  });

  // Calculate statistics
  const totalDays = staffAttendances.length;
  const onTimeCount = staffAttendances.filter((a) => a.status === 'ON_TIME' || (a.status === 'CHECKED_OUT' && !a.notes?.includes('Terlambat'))).length;
  const lateCount = staffAttendances.filter((a) => a.status === 'LATE' || a.notes?.includes('Terlambat')).length;
  const completedShifts = staffAttendances.filter((a) => !!a.check_out_time).length;
  const totalEstimatedHours = staffAttendances.reduce((acc, a) => {
    if (a.check_out_time) {
      const inTime = new Date(a.check_in_time).getTime();
      const outTime = new Date(a.check_out_time).getTime();
      const hours = Math.max(0, (outTime - inTime) / (1000 * 60 * 60));
      return acc + hours;
    }
    return acc + 8; // Standard 8 hours if in progress
  }, 0);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Role Navigation Switcher Tabs (HANYA 2 TAB: APLIKASI ABSENSI & LAPORAN ABSEN) */}
      <div className="bg-white rounded-2xl border border-stone-200 p-2 shadow-xs flex items-center gap-2">
        <button
          onClick={() => onTabChange('absensi_app')}
          className={`flex-1 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            activeTab === 'absensi_app'
              ? 'bg-[#4A2E1B] text-amber-200 shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Aplikasi Absensi</span>
        </button>

        <button
          onClick={() => onTabChange('absensi_laporan')}
          className={`flex-1 py-2.5 px-4 rounded-xl font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer ${
            activeTab === 'absensi_laporan'
              ? 'bg-[#4A2E1B] text-amber-200 shadow-sm'
              : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>Laporan Absen</span>
        </button>
      </div>

      {/* ============================================================== */}
      {/* TAB 1: APLIKASI ABSENSI MANDIRI STAF                            */}
      {/* ============================================================== */}
      {activeTab === 'absensi_app' && (
        <div className="space-y-5">
          {/* Header Card with Real-time Clock & Location */}
          <div className="bg-gradient-to-br from-[#4A2E1B] to-[#2C1810] text-white rounded-3xl p-5 sm:p-6 shadow-md relative overflow-hidden">
            <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                  <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                    Aplikasi Presensi Staf Kafe
                  </span>
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-white">
                  Presensi Mandiri — {currentUser.full_name}
                </h2>
                <div className="flex items-center gap-2 mt-2 flex-wrap text-xs text-amber-100">
                  <span className="flex items-center gap-1 bg-black/30 px-2.5 py-1 rounded-lg">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>Outlet: {activeTenant?.name || 'Young Space Café'}</span>
                  </span>
                  <span className="flex items-center gap-1 bg-black/30 px-2.5 py-1 rounded-lg">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>GPS Radius: Terverifikasi di Kafe</span>
                  </span>
                </div>
              </div>

              {/* Digital WIB Clock */}
              <div className="bg-black/40 border border-amber-500/30 rounded-2xl p-4 text-center min-w-[160px] self-stretch md:self-auto flex flex-col items-center justify-center">
                <span className="text-[10px] font-bold text-amber-300 uppercase tracking-widest block">
                  Waktu Indonesia Barat (WIB)
                </span>
                <span className="text-2xl sm:text-3xl font-black font-mono text-white tracking-wider mt-0.5">
                  {currentTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
                <span className="text-[11px] text-stone-300 mt-0.5">
                  {currentTime.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          </div>

          {/* Status Kehadiran Hari Ini Card */}
          <div className="bg-white rounded-3xl border border-stone-200 p-5 sm:p-6 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-extrabold text-sm sm:text-base text-stone-900 flex items-center gap-2">
                <Calendar className="w-4 h-4 text-[#4A2E1B]" />
                <span>Status Kehadiran Hari Ini ({todayStr})</span>
              </h3>
              {userTodayAttendance ? (
                <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                  userTodayAttendance.status === 'ON_TIME'
                    ? 'bg-emerald-100 text-emerald-800'
                    : userTodayAttendance.status === 'CHECKED_OUT'
                    ? 'bg-stone-100 text-stone-700'
                    : 'bg-amber-100 text-amber-800'
                }`}>
                  {userTodayAttendance.status === 'ON_TIME'
                    ? 'Hadir Tepat Waktu'
                    : userTodayAttendance.status === 'CHECKED_OUT'
                    ? 'Selesai Shift (Checked Out)'
                    : 'Terlambat Masuk'}
                </span>
              ) : (
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-rose-100 text-rose-800">
                  Belum Presensi Masuk
                </span>
              )}
            </div>

            {/* If already checked in */}
            {userTodayAttendance ? (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-stone-50 rounded-2xl p-4 border border-stone-200">
                <div className="flex items-center gap-3">
                  <img
                    src={userTodayAttendance.photo_url}
                    alt="Selfie Check-in"
                    className="w-14 h-14 rounded-2xl object-cover border-2 border-emerald-500 shadow-xs cursor-pointer"
                    onClick={() => setPreviewPhotoModal(userTodayAttendance)}
                  />
                  <div>
                    <span className="text-[10px] text-stone-500 font-semibold block">Waktu Check-In Masuk</span>
                    <span className="text-sm font-extrabold text-stone-900 font-mono">
                      {new Date(userTodayAttendance.check_in_time).toLocaleTimeString('id-ID')} WIB
                    </span>
                    <span className="text-[10px] text-emerald-700 font-bold block mt-0.5">
                      ✓ Foto Terverifikasi
                    </span>
                  </div>
                </div>

                <div className="flex flex-col justify-center">
                  <span className="text-[10px] text-stone-500 font-semibold block">Waktu Check-Out Pulang</span>
                  {userTodayAttendance.check_out_time ? (
                    <span className="text-sm font-extrabold text-stone-900 font-mono">
                      {new Date(userTodayAttendance.check_out_time).toLocaleTimeString('id-ID')} WIB
                    </span>
                  ) : (
                    <span className="text-xs font-bold text-amber-700">
                      Sedang Aktif Bekerja (Shift Berjalan)
                    </span>
                  )}
                  <span className="text-[11px] text-stone-600 truncate mt-0.5">
                    Catatan: {userTodayAttendance.notes || '-'}
                  </span>
                </div>

                <div className="flex items-center justify-end">
                  {!userTodayAttendance.check_out_time ? (
                    <button
                      onClick={() => setShowCheckOutModal(true)}
                      className="w-full md:w-auto px-5 py-3 rounded-2xl bg-stone-900 hover:bg-stone-800 text-white font-extrabold text-xs shadow-md transition flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                    >
                      <LogOut className="w-4 h-4 text-amber-400" />
                      <span>Check-Out (Pulang Shift)</span>
                    </button>
                  ) : (
                    <div className="w-full text-center md:text-right">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>Shift Hari Ini Selesai</span>
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              /* If not checked in yet -> Camera & Check In form */
              <div className="space-y-4">
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div className="text-xs text-amber-900 leading-relaxed">
                    <strong>Ketentuan Presensi Staf:</strong> Jam toleransi masuk shift adalah sebelum pukul <strong>09:00 WIB</strong>. 
                    Ambil foto selfie mandiri dengan seragam/apron kafe yang rapi.
                  </div>
                </div>

                {/* Camera / Photo preview area */}
                <div className="max-w-md mx-auto bg-stone-900 rounded-3xl overflow-hidden border border-stone-800 relative aspect-4/3 flex flex-col items-center justify-center text-white shadow-inner">
                  {isCameraActive ? (
                    <div className="relative w-full h-full">
                      <video
                        ref={videoRef}
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-4 left-0 right-0 flex items-center justify-center gap-4 z-20">
                        <button
                          type="button"
                          onClick={handleSnapCamera}
                          className="px-6 py-2.5 rounded-full bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs shadow-lg transition active:scale-95 flex items-center gap-2 cursor-pointer"
                        >
                          <Camera className="w-4 h-4" />
                          <span>Ambil Foto Selfie</span>
                        </button>
                        <button
                          type="button"
                          onClick={stopCamera}
                          className="px-4 py-2.5 rounded-full bg-black/60 hover:bg-black/80 text-white font-bold text-xs transition cursor-pointer"
                        >
                          Batal
                        </button>
                      </div>
                    </div>
                  ) : capturedPhoto ? (
                    <div className="relative w-full h-full">
                      <img
                        src={capturedPhoto}
                        alt="Hasil Selfie"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute top-3 right-3 bg-emerald-600 text-white text-[10px] font-extrabold px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Foto Siap Dikirim</span>
                      </div>
                      <div className="absolute bottom-3 left-3 right-3 flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setCapturedPhoto(null);
                            startCamera();
                          }}
                          className="px-4 py-2 rounded-xl bg-black/70 hover:bg-black/90 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer backdrop-blur-xs"
                        >
                          <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                          <span>Foto Ulang</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="p-6 text-center space-y-3">
                      <div className="w-16 h-16 rounded-3xl bg-white/10 text-amber-400 flex items-center justify-center mx-auto">
                        <Camera className="w-8 h-8" />
                      </div>
                      <div>
                        <h4 className="font-bold text-sm text-white">Verifikasi Foto Selfie Wajah</h4>
                        <p className="text-xs text-stone-400 mt-1 max-w-xs mx-auto">
                          Wajib mengambil foto selfie langsung menggunakan kamera perangkat Anda.
                        </p>
                      </div>
                      <div className="flex flex-col sm:flex-row items-center justify-center gap-2.5 pt-2">
                        <button
                          type="button"
                          onClick={startCamera}
                          className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-black text-xs transition shadow-md flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <Camera className="w-4 h-4" />
                          <span>Buka Kamera Sekarang</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => fileInputRef.current?.click()}
                          className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <span>Pilih Foto File</span>
                        </button>
                        <input
                          ref={fileInputRef}
                          type="file"
                          accept="image/*"
                          capture="user"
                          className="hidden"
                          onChange={handleFileSelect}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {cameraError && (
                  <p className="text-xs text-amber-600 text-center">{cameraError}</p>
                )}

                {/* Optional Attendance Note */}
                <div className="max-w-md mx-auto space-y-1.5">
                  <label className="block text-xs font-bold text-stone-700">
                    Keterangan Tambahan / Catatan Shift (Opsional):
                  </label>
                  <input
                    type="text"
                    value={attendanceNote}
                    onChange={(e) => setAttendanceNote(e.target.value)}
                    placeholder="Contoh: Shift pagi barista, siap melayani opening"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-stone-300 text-xs sm:text-sm focus:border-amber-600 focus:outline-none"
                  />
                </div>

                {/* Submit Check In Button */}
                <div className="max-w-md mx-auto pt-2">
                  <button
                    type="button"
                    onClick={handleCheckInSubmit}
                    disabled={!capturedPhoto || isSubmitting}
                    className="w-full py-3.5 px-4 rounded-2xl bg-[#4A2E1B] hover:bg-[#3D2616] text-amber-200 font-black text-xs sm:text-sm shadow-md transition disabled:opacity-50 cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <span>Menyimpan Presensi...</span>
                    ) : (
                      <>
                        <LogIn className="w-4 h-4" />
                        <span>KIRIM ABSENSI MASUK (CHECK-IN)</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* TAB 2: LAPORAN ABSEN STAF                                      */}
      {/* ============================================================== */}
      {activeTab === 'absensi_laporan' && (
        <div className="space-y-5">
          {/* Header & Print Action */}
          <div className="bg-white rounded-3xl border border-stone-200 p-5 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-stone-900 flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-[#4A2E1B]" />
                <span>Laporan & Rekap Kehadiran Saya</span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                Riwayat absensi dan akumulasi jam kerja staf: <strong>{currentUser.full_name}</strong>
              </p>
            </div>

            <button
              onClick={() => setShowPrintModal(true)}
              className="px-4 py-2.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-2 cursor-pointer"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              <span>Cetak / Ekspor Laporan</span>
            </button>
          </div>

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block">Total Hadir</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-black text-stone-900">{totalDays}</span>
                <span className="text-xs text-stone-500 font-bold">Hari</span>
              </div>
              <span className="text-[10px] text-stone-400 block mt-1">Periode aktif</span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block">Tepat Waktu</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-black text-emerald-600">{onTimeCount}</span>
                <span className="text-xs text-stone-500 font-bold">Hari</span>
              </div>
              <span className="text-[10px] text-emerald-700 font-bold block mt-1">
                {totalDays > 0 ? Math.round((onTimeCount / totalDays) * 100) : 100}% Kedisiplinan
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block">Terlambat</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-black text-amber-600">{lateCount}</span>
                <span className="text-xs text-stone-500 font-bold">Hari</span>
              </div>
              <span className="text-[10px] text-amber-700 font-semibold block mt-1">
                {lateCount > 0 ? 'Toleransi 09:00 WIB' : 'Nihil keterlambatan'}
              </span>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block">Total Jam Kerja</span>
              <div className="flex items-baseline gap-1 mt-1">
                <span className="text-2xl font-black text-[#4A2E1B]">{Math.round(totalEstimatedHours)}</span>
                <span className="text-xs text-stone-500 font-bold">Jam</span>
              </div>
              <span className="text-[10px] text-stone-500 block mt-1">
                {completedShifts} shift selesai
              </span>
            </div>
          </div>

          {/* Filtering Controls */}
          <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 flex-wrap">
              {/* Period selection */}
              <div className="flex items-center bg-stone-100 p-1 rounded-xl text-xs font-bold">
                <button
                  onClick={() => setReportPeriod('MONTH')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    reportPeriod === 'MONTH' ? 'bg-[#4A2E1B] text-white shadow-xs' : 'text-stone-600'
                  }`}
                >
                  Bulan Ini
                </button>
                <button
                  onClick={() => setReportPeriod('WEEK')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    reportPeriod === 'WEEK' ? 'bg-[#4A2E1B] text-white shadow-xs' : 'text-stone-600'
                  }`}
                >
                  7 Hari Terakhir
                </button>
                <button
                  onClick={() => setReportPeriod('ALL')}
                  className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                    reportPeriod === 'ALL' ? 'bg-[#4A2E1B] text-white shadow-xs' : 'text-stone-600'
                  }`}
                >
                  Semua
                </button>
              </div>

              {/* Status selection */}
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs font-bold text-stone-700 outline-none"
              >
                <option value="ALL">Semua Status</option>
                <option value="ON_TIME">Tepat Waktu</option>
                <option value="LATE">Terlambat</option>
                <option value="CHECKED_OUT">Sudah Check-Out</option>
              </select>
            </div>

            {/* Search Box */}
            <div className="relative min-w-[200px]">
              <Search className="w-3.5 h-3.5 absolute left-3 top-3 text-stone-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Cari tanggal/catatan..."
                className="w-full pl-9 pr-3 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs outline-none focus:border-amber-600"
              />
            </div>
          </div>

          {/* Attendance Table / List */}
          <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-stone-50 border-b border-stone-200 text-stone-600 font-extrabold text-[11px] uppercase tracking-wider">
                    <th className="py-3 px-4">Tanggal & Shift</th>
                    <th className="py-3 px-4">Foto Selfie</th>
                    <th className="py-3 px-4">Jam Masuk</th>
                    <th className="py-3 px-4">Jam Pulang</th>
                    <th className="py-3 px-4">Durasi</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Catatan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-stone-100 text-stone-800">
                  {staffAttendances.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="py-12 text-center text-stone-400">
                        Belum ada riwayat absensi pada filter periode ini.
                      </td>
                    </tr>
                  ) : (
                    staffAttendances.map((att) => {
                      const inDate = new Date(att.check_in_time);
                      const outDate = att.check_out_time ? new Date(att.check_out_time) : null;
                      const durationHours = outDate 
                        ? ((outDate.getTime() - inDate.getTime()) / (1000 * 60 * 60)).toFixed(1)
                        : null;

                      return (
                        <tr key={att.id} className="hover:bg-amber-50/50 transition">
                          <td className="py-3 px-4 font-bold text-stone-900 whitespace-nowrap">
                            {att.date}
                            <span className="block text-[10px] text-stone-500 font-normal">
                              {new Date(att.date).toLocaleDateString('id-ID', { weekday: 'long' })}
                            </span>
                          </td>
                          <td className="py-3 px-4">
                            <button
                              type="button"
                              onClick={() => setPreviewPhotoModal(att)}
                              className="group relative rounded-xl overflow-hidden border border-stone-300 w-10 h-10 block cursor-pointer"
                              title="Klik untuk melihat foto selfie"
                            >
                              <img
                                src={att.photo_url}
                                alt="Selfie"
                                className="w-full h-full object-cover group-hover:scale-110 transition duration-200"
                              />
                              <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white transition">
                                <Eye className="w-3.5 h-3.5" />
                              </div>
                            </button>
                          </td>
                          <td className="py-3 px-4 font-mono font-bold text-stone-900">
                            {inDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                          </td>
                          <td className="py-3 px-4 font-mono text-stone-700">
                            {outDate ? (
                              <span className="font-bold">
                                {outDate.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                              </span>
                            ) : (
                              <span className="text-[10px] text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-semibold">
                                Belum Pulang
                              </span>
                            )}
                          </td>
                          <td className="py-3 px-4 font-semibold text-stone-600">
                            {durationHours ? `${durationHours} Jam` : '-'}
                          </td>
                          <td className="py-3 px-4">
                            <span className={`inline-block px-2.5 py-1 rounded-full text-[10px] font-extrabold ${
                              att.status === 'ON_TIME'
                                ? 'bg-emerald-100 text-emerald-800'
                                : att.status === 'CHECKED_OUT'
                                ? 'bg-stone-100 text-stone-700'
                                : 'bg-amber-100 text-amber-800'
                            }`}>
                              {att.status === 'ON_TIME' ? 'Tepat Waktu' : att.status === 'CHECKED_OUT' ? 'Selesai Shift' : 'Terlambat'}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-stone-600 max-w-xs truncate text-[11px]">
                            {att.notes || '-'}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Check-Out Confirmation Modal */}
      {showCheckOutModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <h3 className="font-black text-base text-stone-900 flex items-center gap-2">
                <LogOut className="w-5 h-5 text-amber-700" />
                <span>Konfirmasi Check-Out Pulang</span>
              </h3>
              <button onClick={() => setShowCheckOutModal(false)} className="text-stone-400 hover:text-stone-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Anda akan mengakhiri jam kerja shift hari ini ({todayStr}) pada pukul{' '}
              <strong>{currentTime.toLocaleTimeString('id-ID')} WIB</strong>.
            </p>

            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-stone-700">
                Catatan Akhir Shift / Handover:
              </label>
              <textarea
                value={checkOutNote}
                onChange={(e) => setCheckOutNote(e.target.value)}
                rows={2}
                className="w-full p-3 rounded-xl border border-stone-300 text-xs focus:border-amber-600 focus:outline-none"
              />
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowCheckOutModal(false)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleCheckOutSubmit}
                className="px-5 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white text-xs font-extrabold shadow-md cursor-pointer transition active:scale-95"
              >
                Simpan & Pulang Shift
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Selfie Photo Preview Modal */}
      {previewPhotoModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-stone-900 text-white rounded-3xl max-w-sm w-full overflow-hidden shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm text-white">{previewPhotoModal.staff_name}</h4>
                <p className="text-[10px] text-stone-400">{previewPhotoModal.date} &bull; {previewPhotoModal.role}</p>
              </div>
              <button onClick={() => setPreviewPhotoModal(null)} className="p-1 rounded-full text-stone-400 hover:text-white cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl overflow-hidden border border-stone-700 aspect-4/3 bg-black">
              <img
                src={previewPhotoModal.photo_url}
                alt="Verifikasi Selfie"
                className="w-full h-full object-cover"
              />
            </div>

            <div className="bg-stone-800 p-3 rounded-xl text-xs space-y-1">
              <div className="flex justify-between text-stone-400">
                <span>Check-in:</span>
                <span className="text-white font-mono">{new Date(previewPhotoModal.check_in_time).toLocaleTimeString('id-ID')} WIB</span>
              </div>
              {previewPhotoModal.check_out_time && (
                <div className="flex justify-between text-stone-400">
                  <span>Check-out:</span>
                  <span className="text-white font-mono">{new Date(previewPhotoModal.check_out_time).toLocaleTimeString('id-ID')} WIB</span>
                </div>
              )}
              <div className="flex justify-between text-stone-400">
                <span>Status:</span>
                <span className="text-emerald-400 font-bold">{previewPhotoModal.status}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Printable Recap Modal */}
      {showPrintModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div>
                <h3 className="font-black text-base text-stone-900">Rekap Laporan Presensi Staf</h3>
                <p className="text-xs text-stone-500">KOPIIN Point of Sale & Operasional Café</p>
              </div>
              <button onClick={() => setShowPrintModal(false)} className="text-stone-400 hover:text-stone-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 text-xs space-y-2 font-mono">
              <div className="flex justify-between">
                <span>Nama Staf:</span>
                <span className="font-bold">{currentUser.full_name}</span>
              </div>
              <div className="flex justify-between">
                <span>Peran Akun:</span>
                <span className="font-bold">{currentUser.role}</span>
              </div>
              <div className="flex justify-between">
                <span>Outlet Kafe:</span>
                <span>{activeTenant?.name || 'Young Space Café'}</span>
              </div>
              <div className="flex justify-between">
                <span>Total Hari Kerja:</span>
                <span className="font-bold">{totalDays} Hari</span>
              </div>
              <div className="flex justify-between">
                <span>Kehadiran Tepat Waktu:</span>
                <span className="font-bold text-emerald-700">{onTimeCount} Hari</span>
              </div>
              <div className="flex justify-between">
                <span>Keterlambatan:</span>
                <span className="font-bold text-amber-700">{lateCount} Hari</span>
              </div>
              <div className="flex justify-between">
                <span>Estimasi Jam Kerja:</span>
                <span className="font-bold">{Math.round(totalEstimatedHours)} Jam</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowPrintModal(false)}
                className="px-4 py-2 rounded-xl text-stone-600 text-xs font-bold cursor-pointer"
              >
                Tutup
              </button>
              <button
                type="button"
                onClick={() => {
                  window.print();
                  setShowPrintModal(false);
                }}
                className="px-5 py-2.5 rounded-xl bg-[#4A2E1B] text-amber-200 text-xs font-extrabold shadow-md cursor-pointer flex items-center gap-1.5"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak Lembar Presensi</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
