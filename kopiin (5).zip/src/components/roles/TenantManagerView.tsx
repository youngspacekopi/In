import React, { useState } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { AttendanceModule } from '../desktop/AttendanceModule';
import { TableBarcodeModal } from '../common/TableBarcodeModal';
import { CafeTable } from '../../types/cafe';
import { 
  Users, 
  Clock, 
  ShoppingBag, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldCheck, 
  ArrowRight, 
  Camera, 
  LogOut, 
  Check, 
  X, 
  Coffee, 
  Layers, 
  ChevronRight,
  Eye,
  Plus,
  QrCode,
  Printer
} from 'lucide-react';

interface Props {
  defaultTab?: ManagerTab;
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;
}

export type ManagerTab = 'shift' | 'tables' | 'voids' | 'attendance';

export const TenantManagerView: React.FC<Props> = ({ defaultTab, showToast }) => {
  const { currentUser, hasAccess, activeTenant } = usePlatform();
  const {
    orders,
    tables,
    attendances,
    updateTableStatus,
    voidOrder,
    financialSummary,
    addTable,
  } = useCafe();

  const [activeTab, setActiveTab] = useState<ManagerTab>(defaultTab || 'shift');
  const [selectedTableForBarcode, setSelectedTableForBarcode] = useState<CafeTable | null>(null);

  React.useEffect(() => {
    if (defaultTab) {
      setActiveTab(defaultTab);
    }
  }, [defaultTab]);
  const [selectedVoidOrder, setSelectedVoidOrder] = useState<any | null>(null);
  const [voidReason, setVoidReason] = useState('');

  // Add Table state
  const [showAddTableModal, setShowAddTableModal] = useState(false);
  const [newTableNumber, setNewTableNumber] = useState('');
  const [newTableCapacity, setNewTableCapacity] = useState<number>(4);

  const handleAddTableSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTableNumber.trim()) return;
    addTable(newTableNumber.trim(), Number(newTableCapacity) || 2);
    showToast(`Meja "${newTableNumber.trim()}" (Kapasitas ${newTableCapacity} orang) berhasil ditambahkan!`);
    setShowAddTableModal(false);
    setNewTableNumber('');
    setNewTableCapacity(4);
  };

  const activeOrders = orders.filter((o) => o.status !== 'COMPLETED' && o.status !== 'VOIDED');
  const occupiedTables = tables.filter((t) => t.status === 'OCCUPIED');
  const todayStr = new Date().toISOString().split('T')[0];
  const staffPresent = attendances.filter((a) => a.date === todayStr);

  const handleApproveVoid = () => {
    if (!selectedVoidOrder) return;
    voidOrder(selectedVoidOrder.id, voidReason || 'Disetujui Manager', '1234');
    showToast(`Order #${selectedVoidOrder.order_number} berhasil di-VOID.`);
    setSelectedVoidOrder(null);
    setVoidReason('');
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-120px)] pb-24">
      {/* Banner */}
      <div className="bg-gradient-to-r from-blue-900 via-stone-900 to-indigo-950 text-white p-4 rounded-2xl mb-4 shadow-md">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 border border-blue-400/40 flex items-center justify-center text-blue-300 font-bold text-xs">
              M
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-blue-300">Manager Operasional Café</span>
              <h2 className="text-sm font-extrabold text-white leading-tight">Pengawasan Shift & Kehadiran Staf</h2>
            </div>
          </div>
          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-400/30">
            Supervisor Shift
          </span>
        </div>
        <p className="text-xs text-stone-300 leading-snug">
          Manager bertugas mengawasi kelancaran pesanan kasir, ketersediaan meja, pembagian giliran kerja, dan otorisasi pembatalan order (Void).
        </p>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-4 gap-1.5 p-1 bg-stone-100 rounded-xl mb-4 text-xs font-bold">
        <button
          onClick={() => setActiveTab('shift')}
          className={`py-2 px-1 rounded-lg text-center transition flex flex-col items-center gap-1 cursor-pointer ${
            activeTab === 'shift' ? 'bg-white text-blue-900 shadow-xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Clock className="w-4 h-4" />
          <span className="text-[10px]">Ringkasan Shift</span>
        </button>
        <button
          onClick={() => setActiveTab('tables')}
          className={`py-2 px-1 rounded-lg text-center transition flex flex-col items-center gap-1 cursor-pointer ${
            activeTab === 'tables' ? 'bg-white text-blue-900 shadow-xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span className="text-[10px]">Meja ({occupiedTables.length}/{tables.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('voids')}
          className={`py-2 px-1 rounded-lg text-center transition flex flex-col items-center gap-1 cursor-pointer ${
            activeTab === 'voids' ? 'bg-white text-blue-900 shadow-xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span className="text-[10px]">Void Approval</span>
        </button>
        <button
          onClick={() => setActiveTab('attendance')}
          className={`py-2 px-1 rounded-lg text-center transition flex flex-col items-center gap-1 cursor-pointer ${
            activeTab === 'attendance' ? 'bg-white text-blue-900 shadow-xs' : 'text-stone-500 hover:text-stone-800'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span className="text-[10px]">Absensi ({staffPresent.length})</span>
        </button>
      </div>

      {/* Shift Overview */}
      {activeTab === 'shift' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 bg-white rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block mb-1">Pesanan Aktif Shift Ini</span>
              <p className="text-xl font-extrabold text-[#4A2E1B]">{activeOrders.length} Order</p>
              <span className="text-[10px] text-amber-700 font-semibold">Sedang Diproses Barista</span>
            </div>
            <div className="p-3.5 bg-white rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block mb-1">Meja Terisi</span>
              <p className="text-xl font-extrabold text-[#1F1E1D]">
                {occupiedTables.length} / {tables.length}
              </p>
              <span className="text-[10px] text-emerald-700 font-semibold">
                {tables.length - occupiedTables.length} Meja Kosong
              </span>
            </div>
            <div className="p-3.5 bg-white rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block mb-1">Staf Hadir Hari Ini</span>
              <p className="text-xl font-extrabold text-[#15803D]">{staffPresent.length} Staf</p>
              <span className="text-[10px] text-stone-500">Terverifikasi foto selfie</span>
            </div>
            <div className="p-3.5 bg-white rounded-2xl border border-stone-200 shadow-xs">
              <span className="text-[11px] font-semibold text-stone-500 block mb-1">Kas Laci Terkumpul</span>
              <p className="text-xl font-extrabold text-blue-900">
                Rp{financialSummary.realCashReceived.toLocaleString('id-ID')}
              </p>
              <span className="text-[10px] text-stone-500">Uang tunai kasir shift ini</span>
            </div>
          </div>

          <div className="p-4 bg-white rounded-2xl border border-stone-200 shadow-xs space-y-3">
            <h3 className="font-extrabold text-xs text-[#1F1E1D]">Antrean Order Aktif di Meja</h3>
            <div className="space-y-2">
              {activeOrders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-3 bg-stone-50 rounded-xl border border-stone-200 flex items-center justify-between text-xs"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-amber-900">{ord.order_number}</span>
                      <span className="font-bold text-[#1F1E1D]">{ord.customer_name}</span>
                    </div>
                    <p className="text-[10px] text-stone-500 mt-0.5">
                      {ord.order_type} • Meja {ord.table_number || '-'} • {ord.items.length} Menu
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-100 text-amber-800">
                      {ord.status}
                    </span>
                    <button
                      onClick={() => setSelectedVoidOrder(ord)}
                      className="px-2 py-1 bg-red-100 text-red-800 rounded-lg text-[10px] font-bold hover:bg-red-200 transition cursor-pointer"
                    >
                      Void
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Table Management */}
      {activeTab === 'tables' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-extrabold text-xs text-[#1F1E1D]">Status Okupansi Meja Café</h3>
              <span className="text-[10px] text-stone-500">Total {tables.length} meja aktif</span>
            </div>
            <button
              onClick={() => setShowAddTableModal(true)}
              className="px-3 py-1.5 bg-[#4A2E1B] hover:bg-[#3D2616] text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Tambah Meja</span>
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {tables.map((t) => (
              <div
                key={t.id}
                className={`p-4 rounded-2xl border text-center transition ${
                  t.status === 'AVAILABLE'
                    ? 'bg-emerald-50/50 border-emerald-200'
                    : t.status === 'OCCUPIED'
                    ? 'bg-amber-50/50 border-amber-300'
                    : 'bg-stone-100 border-stone-200'
                }`}
              >
                <span className="text-xs font-bold text-stone-500 block mb-0.5">Meja {t.table_number}</span>
                <span className="text-[10px] text-stone-400 block mb-1 font-mono">Kapasitas {t.capacity} Orang</span>
                <span
                  className={`text-sm font-extrabold block mb-2 ${
                    t.status === 'AVAILABLE'
                      ? 'text-emerald-700'
                      : t.status === 'OCCUPIED'
                      ? 'text-amber-800'
                      : 'text-stone-600'
                  }`}
                >
                  {t.status}
                </span>
                <div className="flex justify-center gap-1 mb-2">
                  <button
                    onClick={() => updateTableStatus(t.id, 'AVAILABLE')}
                    className="px-2 py-1 bg-white border border-emerald-300 text-emerald-800 rounded text-[10px] font-bold hover:bg-emerald-50 cursor-pointer"
                  >
                    Kosong
                  </button>
                  <button
                    onClick={() => updateTableStatus(t.id, 'OCCUPIED')}
                    className="px-2 py-1 bg-white border border-amber-300 text-amber-800 rounded text-[10px] font-bold hover:bg-amber-50 cursor-pointer"
                  >
                    Terisi
                  </button>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedTableForBarcode(t)}
                  className="w-full py-1.5 px-2 bg-[#4A2E1B] hover:bg-[#3D2616] text-amber-200 rounded-xl text-[10px] font-extrabold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs active:scale-95"
                  title="Lihat, cetak, atau unduh Barcode & QR Meja"
                >
                  <QrCode className="w-3.5 h-3.5 text-amber-400" />
                  <span>Barcode & QR Meja</span>
                </button>
              </div>
            ))}
          </div>

          {/* Add Table Modal */}
          {showAddTableModal && (
            <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4 animate-in fade-in duration-150">
              <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-stone-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-100 text-[#4A2E1B] flex items-center justify-center font-bold">
                      <Layers className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-extrabold text-sm text-[#1F1E1D]">Tambah Meja Baru</h4>
                      <p className="text-[10px] text-stone-500">Daftarkan nomor meja untuk pesanan dine-in</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setShowAddTableModal(false)}
                    className="p-1.5 text-stone-400 hover:text-stone-600 rounded-lg hover:bg-stone-100"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <form onSubmit={handleAddTableSubmit} className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Nomor / Nama Meja <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: Meja 11 atau Outdoor 02"
                      value={newTableNumber}
                      onChange={(e) => setNewTableNumber(e.target.value)}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:border-[#4A2E1B] outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Kapasitas Kursi (Orang) <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={20}
                      value={newTableCapacity}
                      onChange={(e) => setNewTableCapacity(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs rounded-xl border border-stone-300 focus:border-[#4A2E1B] outline-none font-mono"
                    />
                  </div>

                  <div className="flex gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setShowAddTableModal(false)}
                      className="flex-1 py-2 rounded-xl text-xs font-bold text-stone-600 bg-stone-100 hover:bg-stone-200 transition"
                    >
                      Batal
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2 rounded-xl text-xs font-bold text-white bg-[#4A2E1B] hover:bg-[#3D2616] transition shadow-xs"
                    >
                      Simpan Meja
                    </button>
                  </div>
                </form>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Void Orders */}
      {activeTab === 'voids' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900">
            <h4 className="font-bold flex items-center gap-1.5 mb-1">
              <ShieldCheck className="w-4 h-4 text-amber-800" />
              Otoritas Khusus Supervisor
            </h4>
            <p className="text-[11px] text-amber-800">
              Kasir tidak dapat membatalkan pesanan tanpa persetujuan Manager. Setiap aksi void dicatat dalam Audit Trail.
            </p>
          </div>

          <div className="space-y-2">
            {orders.map((ord) => (
              <div
                key={ord.id}
                className="p-3 bg-white rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between text-xs"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-[#4A2E1B]">{ord.order_number}</span>
                    <span className="font-bold text-[#1F1E1D]">{ord.customer_name}</span>
                  </div>
                  <span className="text-[10px] text-stone-500 font-mono">
                    Rp{ord.total_amount.toLocaleString('id-ID')} • {ord.status}
                  </span>
                </div>
                {ord.status !== 'VOIDED' && (
                  <button
                    onClick={() => setSelectedVoidOrder(ord)}
                    className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition cursor-pointer"
                  >
                    Void Order
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Attendance Module Tab */}
      {activeTab === 'attendance' && (
        <div className="space-y-4 animate-in fade-in duration-200">
          <AttendanceModule />
        </div>
      )}

      {/* Modal Void Confirmation */}
      {selectedVoidOrder && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl p-5 shadow-2xl border border-stone-200 space-y-4">
            <h3 className="font-bold text-sm text-red-600 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Konfirmasi Otorisasi VOID
            </h3>
            <p className="text-xs text-stone-600">
              Apakah Anda yakin ingin membatalkan Order <strong>#{selectedVoidOrder.order_number}</strong> (Rp{selectedVoidOrder.total_amount.toLocaleString('id-ID')})?
            </p>
            <div>
              <label className="font-bold text-xs text-stone-700 block mb-1">Alasan Pembatalan *</label>
              <input
                type="text"
                required
                placeholder="Pelanggan ganti pesanan / salah input..."
                value={voidReason}
                onChange={(e) => setVoidReason(e.target.value)}
                className="w-full px-3 py-2 border border-stone-300 rounded-xl text-xs outline-none focus:border-red-600"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-stone-100">
              <button
                onClick={() => setSelectedVoidOrder(null)}
                className="px-4 py-2 border border-stone-300 text-stone-700 rounded-xl text-xs font-bold hover:bg-stone-50 cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleApproveVoid}
                className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold cursor-pointer"
              >
                Ya, Setujui VOID
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table Barcode & QR Code Tent Modal */}
      {selectedTableForBarcode && (
        <TableBarcodeModal
          isOpen={!!selectedTableForBarcode}
          onClose={() => setSelectedTableForBarcode(null)}
          table={selectedTableForBarcode}
          tenant={activeTenant}
          showToast={showToast}
        />
      )}
    </div>
  );
};
