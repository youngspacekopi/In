import React, { useState } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { 
  Coffee, 
  Search, 
  Sparkles, 
  Gift, 
  CheckCircle2, 
  UserPlus, 
  Info,
  ChevronRight
} from 'lucide-react';

interface Props {
  onRegisterMember?: () => void;
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;
}

export const GuestView: React.FC<Props> = ({ onRegisterMember, showToast }) => {
  const { activeTenant } = usePlatform();
  const { menuItems, categories } = useCafe();

  // Check URL query for table param (e.g. from Barcode scan)
  const [tableNumber, setTableNumber] = useState<string | null>(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      return params.get('table');
    } catch {
      return null;
    }
  });

  const [search, setSearch] = useState('');
  const [selectedCat, setSelectedCat] = useState('ALL');

  const filtered = menuItems.filter((m) => {
    if (selectedCat !== 'ALL' && m.category_id !== selectedCat) return false;
    if (search && !m.name.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="flex flex-col min-h-[calc(100vh-120px)] pb-24 space-y-4">
      {/* Table Scanned Alert Banner */}
      {tableNumber && (
        <div className="p-3 bg-emerald-50 border border-emerald-300 rounded-2xl flex items-center justify-between text-xs text-emerald-900 shadow-xs animate-in slide-in-from-top-2">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 animate-pulse shrink-0" />
            <span>
              Terhubung ke <strong>Meja {tableNumber}</strong> via Barcode Scan &bull; Dine-In
            </span>
          </div>
          <button
            onClick={() => setTableNumber(null)}
            className="text-[10px] font-bold text-stone-500 hover:text-stone-800 underline cursor-pointer"
          >
            Lepas Meja
          </button>
        </div>
      )}

      {/* Guest Welcome Hero */}
      <div className="bg-gradient-to-r from-[#4A2E1B] via-[#361F12] to-stone-900 text-white p-5 rounded-3xl shadow-md">
        <div className="flex items-center gap-2 mb-1.5">
          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-500/20 text-amber-300 border border-amber-500/30">
            BUKU MENU DIGITAL
          </span>
          <span className="text-[10px] text-stone-300 font-mono">DINE-IN & TAKEAWAY</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight">{activeTenant?.name || 'KOPIIN Café'}</h2>
        <p className="text-xs text-stone-300 mt-1">
          Silakan jelajahi pilihan minuman racikan barista dan sajian pastry kami. Pesan langsung di kasir atau daftar member untuk cashback poin.
        </p>

        {/* Member Promotion Banner */}
        <div className="mt-4 p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Gift className="w-5 h-5 text-amber-300 shrink-0" />
            <div>
              <p className="font-extrabold text-xs text-white">Daftar Jadi Member KOPIIN</p>
              <p className="text-[10px] text-amber-200">Dapatkan cashback 5% poin setiap pembelian</p>
            </div>
          </div>
          {onRegisterMember && (
            <button
              onClick={onRegisterMember}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 rounded-xl text-xs font-bold transition cursor-pointer shrink-0"
            >
              Daftar Gratis
            </button>
          )}
        </div>
      </div>

      {/* Search & Categories */}
      <div className="space-y-2">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-2.5 text-stone-400" />
          <input
            type="text"
            placeholder="Cari kopi susu, teh, croissant..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-stone-200 text-xs outline-none shadow-2xs"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto pb-1">
          <button
            onClick={() => setSelectedCat('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
              selectedCat === 'ALL'
                ? 'bg-[#4A2E1B] text-white shadow-xs'
                : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-50'
            }`}
          >
            Semua
          </button>
          {categories.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedCat(c.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                selectedCat === c.id
                  ? 'bg-[#4A2E1B] text-white shadow-xs'
                  : 'bg-white text-stone-600 border border-stone-200 hover:bg-stone-50'
              }`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      {/* Catalog Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {filtered.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl border border-stone-200 p-2.5 shadow-xs flex flex-col justify-between"
          >
            <div className="aspect-4/3 rounded-xl overflow-hidden bg-stone-100 mb-2">
              <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
            </div>
            <div>
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-xs text-[#1F1E1D] line-clamp-1">{item.name}</h4>
                <span
                  className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                    item.is_available ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}
                >
                  {item.is_available ? 'Ready' : 'Habis'}
                </span>
              </div>
              <p className="text-[10px] text-stone-500 line-clamp-2 mt-0.5">{item.description}</p>
              <div className="mt-2 pt-1 border-t border-stone-100 flex items-center justify-between">
                <span className="font-mono font-bold text-xs text-[#4A2E1B]">
                  Rp{item.price.toLocaleString('id-ID')}
                </span>
                <span className="text-[10px] text-stone-400 font-mono">+11% PPN</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
