/**
 * KOPIIN — Desktop Presentation Console (1440px+)
 * Complete Multi-Role Management Interface:
 * - PLATFORM_MASTER: Multi-tenant provisioner, owner account manager, global audit trail
 * - TENANT_OWNER: Business KPIs, POS kasir, KDS barista, menu & resep HPP, gudang stok, arus kas laci, staf, laporan laba rugi, poin member
 * - TENANT_MANAGER: Shift operasional, denah meja, persetujuan void order, absensi shift
 * - STAFF_CASHIER: Kasir POS billing cepat & cetak struk
 * - STAFF_BARISTA: Kitchen Display System (KDS) & antrean resep
 * - STAFF_STOKIS: Gudang bahan baku, opname stok, faktur restok
 * - MEMBER: Kartu loyalitas, saldo poin, katalog reward
 * - GUEST: Menu digital publik & self-order
 */

import React, { useState, useEffect } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { PlatformMasterView } from '../roles/PlatformMasterView';
import { TenantOwnerView } from '../roles/TenantOwnerView';
import { TenantManagerView } from '../roles/TenantManagerView';
import { StaffCashierView } from '../roles/StaffCashierView';
import { StaffBaristaView } from '../roles/StaffBaristaView';
import { StaffStokisView } from '../roles/StaffStokisView';
import { MemberView } from '../roles/MemberView';
import { GuestView } from '../roles/GuestView';
import { AttendanceModule } from '../desktop/AttendanceModule';
import { FinancialReportsModule } from '../desktop/FinancialReportsModule';
import { ProductManagementModal } from '../desktop/ProductManagementModal';
import { PrinterSettingsModal } from '../common/PrinterSettingsModal';
import { 
  Building2, 
  TrendingUp, 
  ShoppingBag, 
  Coffee, 
  Layers, 
  Boxes, 
  DollarSign, 
  Users, 
  FileSpreadsheet, 
  Award, 
  Printer, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  Plus, 
  X, 
  Check, 
  AlertCircle 
} from 'lucide-react';

interface Props {
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;
}

export const DesktopPresentation: React.FC<Props> = ({ showToast }) => {
  const { 
    currentUser, 
    activeTenant, 
    tenants, 
    switchTenant, 
    registerTenant 
  } = usePlatform();

  const { 
    menuItems, 
    categories, 
    addMenuItem, 
    updateMenuItem, 
    addCategory, 
    addCashMovement 
  } = useCafe();

  const role = currentUser.role;

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('default');

  // Sync default tab when user switches role
  useEffect(() => {
    switch (role) {
      case 'PLATFORM_MASTER':
        setActiveTab('master_tenants');
        break;
      case 'TENANT_OWNER':
        setActiveTab('owner_overview');
        break;
      case 'TENANT_MANAGER':
        setActiveTab('manager_shift');
        break;
      case 'STAFF_CASHIER':
        setActiveTab('pos');
        break;
      case 'STAFF_BARISTA':
        setActiveTab('kds');
        break;
      case 'STAFF_STOKIS':
        setActiveTab('stokis_inventory');
        break;
      case 'MEMBER':
        setActiveTab('member_portal');
        break;
      case 'GUEST':
        setActiveTab('guest_portal');
        break;
      default:
        setActiveTab('owner_overview');
    }
  }, [role]);

  // Modals state
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  const [showCashModal, setShowCashModal] = useState(false);
  const [mutationType, setMutationType] = useState<'KAS_MASUK' | 'KAS_KELUAR'>('KAS_KELUAR');
  const [mutationAmount, setMutationAmount] = useState<number>(50000);
  const [mutationCategory, setMutationCategory] = useState('Beli Es Batu / Galon');
  const [mutationNotes, setMutationNotes] = useState('');

  const [showPrinterModal, setShowPrinterModal] = useState(false);

  // Platform Master: Add Tenant Modal
  const [showAddTenantModal, setShowAddTenantModal] = useState(false);
  const [tenantNameInput, setTenantNameInput] = useState('');
  const [tenantSlugInput, setTenantSlugInput] = useState('');
  const [ownerNameInput, setOwnerNameInput] = useState('');
  const [ownerEmailInput, setOwnerEmailInput] = useState('');
  const [ownerPasswordInput, setOwnerPasswordInput] = useState('KopiinOwner2026!');
  const [taxRateInput, setTaxRateInput] = useState('11');
  const [serviceChargeInput, setServiceChargeInput] = useState('5');
  const [isSubmittingTenant, setIsSubmittingTenant] = useState(false);
  const [tenantModalError, setTenantModalError] = useState<string | null>(null);

  const handleCreateTenantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantNameInput.trim() || !ownerEmailInput.trim() || !ownerNameInput.trim()) {
      setTenantModalError('Harap lengkapi nama café, nama owner, dan email owner.');
      return;
    }
    setTenantModalError(null);
    setIsSubmittingTenant(true);
    try {
      const slug = tenantSlugInput.trim() || tenantNameInput.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const result = await registerTenant({
        tenantName: tenantNameInput.trim(),
        tenantSlug: slug,
        ownerFullName: ownerNameInput.trim(),
        ownerEmail: ownerEmailInput.trim(),
        ownerPasswordPlainText: ownerPasswordInput || 'KopiinOwner2026!',
        taxRate: parseFloat(taxRateInput) / 100 || 0.11,
        serviceCharge: parseFloat(serviceChargeInput) / 100 || 0.05,
      });

      showToast(`Tenant "${result.tenant.name}" & Akun Owner (${result.owner.email}) berhasil dibuat!`, 'success');
      setShowAddTenantModal(false);
      setTenantNameInput('');
      setTenantSlugInput('');
      setOwnerNameInput('');
      setOwnerEmailInput('');
    } catch (err: any) {
      setTenantModalError(err?.message || 'Gagal mendaftarkan tenant.');
    } finally {
      setIsSubmittingTenant(false);
    }
  };

  const handleCashSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mutationAmount || mutationAmount <= 0) return;
    addCashMovement({
      movement_type: mutationType,
      category: mutationCategory,
      amount: Number(mutationAmount),
      notes: mutationNotes,
    });
    showToast(`Mutasi kas ${mutationType === 'KAS_MASUK' ? 'Masuk' : 'Keluar'} Rp${mutationAmount.toLocaleString('id-ID')} berhasil dicatat!`, 'success');
    setShowCashModal(false);
    setMutationNotes('');
  };

  // Nav Items definition for each role
  const renderNavItems = () => {
    if (role === 'PLATFORM_MASTER') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            SuperAdmin Platform
          </div>
          <button
            onClick={() => setActiveTab('master_tenants')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'master_tenants'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Building2 className="w-4 h-4 text-amber-500" />
            <span>Kelola Tenant Café</span>
          </button>
          <button
            onClick={() => setActiveTab('master_metrics')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'master_metrics'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-emerald-500" />
            <span>Metrik Platform SaaS</span>
          </button>
          <button
            onClick={() => setActiveTab('master_audit')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'master_audit'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Clock className="w-4 h-4 text-blue-500" />
            <span>Audit Trail Realtime</span>
          </button>
          <button
            onClick={() => setActiveTab('master_security')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'master_security'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-purple-500" />
            <span>Keamanan & Isolasi RBAC</span>
          </button>
        </>
      );
    }

    if (role === 'TENANT_OWNER') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Operasional Bisnis
          </div>
          <button
            onClick={() => setActiveTab('owner_overview')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_overview'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <span>Ringkasan Finansial & KPI</span>
          </button>
          <button
            onClick={() => setActiveTab('pos')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'pos'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-emerald-500" />
            <span>Kasir POS & Transaksi</span>
          </button>
          <button
            onClick={() => setActiveTab('kds')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'kds'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Coffee className="w-4 h-4 text-orange-500" />
            <span>Kitchen Barista (KDS)</span>
          </button>
          <button
            onClick={() => setActiveTab('owner_products')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_products'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Layers className="w-4 h-4 text-indigo-500" />
            <span>Menu & Resep HPP</span>
          </button>
          <button
            onClick={() => setActiveTab('stokis_inventory')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'stokis_inventory'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Boxes className="w-4 h-4 text-amber-600" />
            <span>Gudang & Bahan Baku</span>
          </button>
          <button
            onClick={() => setActiveTab('owner_cashflow')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_cashflow'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Buku Kas Laci & Mutasi</span>
          </button>

          <div className="pt-2 text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            SDM & Pelanggan
          </div>
          <button
            onClick={() => setActiveTab('owner_staff')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_staff'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Users className="w-4 h-4 text-blue-500" />
            <span>Tim Staf & Absensi</span>
          </button>
          <button
            onClick={() => setActiveTab('owner_reports')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_reports'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4 text-purple-600" />
            <span>Laporan Laba Rugi Akuntansi</span>
          </button>
          <button
            onClick={() => setActiveTab('owner_loyalty')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'owner_loyalty'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Award className="w-4 h-4 text-rose-500" />
            <span>Poin Loyalitas Member</span>
          </button>
          <button
            onClick={() => setShowPrinterModal(true)}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-stone-900"
          >
            <Printer className="w-4 h-4 text-stone-500" />
            <span>Pengaturan Printer POS</span>
          </button>
        </>
      );
    }

    if (role === 'TENANT_MANAGER') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Supervisi Shift
          </div>
          <button
            onClick={() => setActiveTab('manager_shift')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'manager_shift'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Clock className="w-4 h-4 text-amber-500" />
            <span>Shift Operasional & Kas</span>
          </button>
          <button
            onClick={() => setActiveTab('manager_tables')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'manager_tables'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Layers className="w-4 h-4 text-blue-500" />
            <span>Denah Meja & Kapasitas</span>
          </button>
          <button
            onClick={() => setActiveTab('manager_voids')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'manager_voids'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-rose-500" />
            <span>Persetujuan Void Order</span>
          </button>
          <button
            onClick={() => setActiveTab('pos')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'pos'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-emerald-500" />
            <span>Kasir POS Kasir</span>
          </button>
          <button
            onClick={() => setActiveTab('kds')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'kds'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Coffee className="w-4 h-4 text-orange-500" />
            <span>Display Barista (KDS)</span>
          </button>
          <button
            onClick={() => setActiveTab('manager_attendance')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'manager_attendance'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-purple-500" />
            <span>Absensi Staf Shift</span>
          </button>
        </>
      );
    }

    if (role === 'STAFF_CASHIER') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Terminal Kasir
          </div>
          <button
            onClick={() => setActiveTab('pos')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'pos'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-emerald-500" />
            <span>Mesin Kasir POS</span>
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'attendance'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-purple-500" />
            <span>Absensi Shift Saya</span>
          </button>
          <button
            onClick={() => setShowPrinterModal(true)}
            className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold text-stone-600 hover:bg-stone-100 hover:text-stone-900"
          >
            <Printer className="w-4 h-4 text-stone-500" />
            <span>Pengaturan Printer Struk</span>
          </button>
        </>
      );
    }

    if (role === 'STAFF_BARISTA') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Bar & Kitchen
          </div>
          <button
            onClick={() => setActiveTab('kds')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'kds'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Coffee className="w-4 h-4 text-orange-500" />
            <span>Kitchen Display System (KDS)</span>
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'attendance'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-purple-500" />
            <span>Absensi Shift Saya</span>
          </button>
        </>
      );
    }

    if (role === 'STAFF_STOKIS') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Gudang & Logistik
          </div>
          <button
            onClick={() => setActiveTab('stokis_inventory')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'stokis_inventory'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Boxes className="w-4 h-4 text-amber-600" />
            <span>Stok & Restok Bahan Baku</span>
          </button>
          <button
            onClick={() => setActiveTab('attendance')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'attendance'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Calendar className="w-4 h-4 text-purple-500" />
            <span>Absensi Shift Saya</span>
          </button>
        </>
      );
    }

    if (role === 'MEMBER') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Akun Member
          </div>
          <button
            onClick={() => setActiveTab('member_portal')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'member_portal'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Sparkles className="w-4 h-4 text-rose-500" />
            <span>Kartu Loyalitas & Poin</span>
          </button>
        </>
      );
    }

    if (role === 'GUEST') {
      return (
        <>
          <div className="text-[10px] font-bold text-stone-400 uppercase tracking-wider px-3 mb-1">
            Katalog Publik
          </div>
          <button
            onClick={() => setActiveTab('guest_portal')}
            className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl transition cursor-pointer text-xs font-semibold ${
              activeTab === 'guest_portal'
                ? 'bg-[#4A2E1B] text-white shadow-xs font-bold'
                : 'text-stone-600 hover:bg-stone-100 hover:text-stone-900'
            }`}
          >
            <Coffee className="w-4 h-4 text-amber-600" />
            <span>Buku Menu & Pesan</span>
          </button>
        </>
      );
    }

    return null;
  };

  return (
    <div className="min-h-screen bg-[#FDFBF7] flex">
      {/* Desktop Sidebar (Wide Navigation) */}
      <aside className="w-72 bg-white border-r border-[#E5DFD7] flex flex-col justify-between shrink-0 p-4 sticky top-12 h-[calc(100vh-48px)] overflow-y-auto">
        <div className="space-y-5">
          {/* Café Outlet Header */}
          <div className="p-3.5 bg-[#FAF8F5] border border-[#E5DFD7] rounded-2xl flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#4A2E1B] text-white flex items-center justify-center font-black text-sm shadow-xs shrink-0">
              {activeTenant?.name ? activeTenant.name.slice(0, 2).toUpperCase() : 'KP'}
            </div>
            <div className="min-w-0">
              <h3 className="font-extrabold text-xs text-[#1F1E1D] truncate">
                {activeTenant?.name || 'KOPIIN Café'}
              </h3>
              <p className="text-[10px] text-stone-500 font-mono truncate">
                PB1: {((activeTenant?.settings?.tax_rate || 0.11) * 100)}% | Servis: {((activeTenant?.settings?.service_charge || 0.05) * 100)}%
              </p>
            </div>
          </div>

          {/* Role Nav Links */}
          <nav className="space-y-1">
            {renderNavItems()}
          </nav>
        </div>

        {/* User Session Footer Badge */}
        <div className="pt-4 border-t border-[#E5DFD7] space-y-2">
          <div className="p-3 bg-[#FAF8F5] border border-[#E5DFD7] rounded-2xl flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-amber-700 text-white font-bold text-xs flex items-center justify-center shrink-0">
              {currentUser.full_name.slice(0, 1)}
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-extrabold text-xs text-[#1F1E1D] truncate">{currentUser.full_name}</p>
              <span className="text-[10px] text-amber-800 font-semibold font-mono block truncate">
                {currentUser.role}
              </span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Workspace Frame */}
      <main className="flex-1 p-6 overflow-y-auto max-w-7xl mx-auto space-y-6">
        {/* PLATFORM MASTER TABS */}
        {activeTab === 'master_tenants' && (
          <PlatformMasterView
            defaultTab="tenants"
            onOpenAddTenant={() => setShowAddTenantModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'master_metrics' && (
          <PlatformMasterView
            defaultTab="metrics"
            onOpenAddTenant={() => setShowAddTenantModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'master_audit' && (
          <PlatformMasterView
            defaultTab="audit"
            onOpenAddTenant={() => setShowAddTenantModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'master_security' && (
          <PlatformMasterView
            defaultTab="security"
            onOpenAddTenant={() => setShowAddTenantModal(true)}
            showToast={showToast}
          />
        )}

        {/* TENANT OWNER TABS */}
        {activeTab === 'owner_overview' && (
          <TenantOwnerView
            defaultTab="overview"
            onOpenNewProduct={() => {
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            onOpenCashModal={() => setShowCashModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'owner_products' && (
          <TenantOwnerView
            defaultTab="products"
            onOpenNewProduct={() => {
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            onOpenCashModal={() => setShowCashModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'owner_cashflow' && (
          <TenantOwnerView
            defaultTab="cashflow"
            onOpenNewProduct={() => {
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            onOpenCashModal={() => setShowCashModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'owner_staff' && (
          <TenantOwnerView
            defaultTab="staff"
            onOpenNewProduct={() => {
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            onOpenCashModal={() => setShowCashModal(true)}
            showToast={showToast}
          />
        )}
        {activeTab === 'owner_reports' && (
          <FinancialReportsModule />
        )}
        {activeTab === 'owner_loyalty' && (
          <TenantOwnerView
            defaultTab="loyalty"
            onOpenNewProduct={() => {
              setEditingProduct(null);
              setShowProductModal(true);
            }}
            onOpenCashModal={() => setShowCashModal(true)}
            showToast={showToast}
          />
        )}

        {/* TENANT MANAGER TABS */}
        {activeTab === 'manager_shift' && (
          <TenantManagerView defaultTab="shift" showToast={showToast} />
        )}
        {activeTab === 'manager_tables' && (
          <TenantManagerView defaultTab="tables" showToast={showToast} />
        )}
        {activeTab === 'manager_voids' && (
          <TenantManagerView defaultTab="voids" showToast={showToast} />
        )}
        {activeTab === 'manager_attendance' && (
          <TenantManagerView defaultTab="attendance" showToast={showToast} />
        )}

        {/* CASHIER POS */}
        {activeTab === 'pos' && (
          <StaffCashierView showToast={showToast} />
        )}

        {/* BARISTA KDS */}
        {activeTab === 'kds' && (
          <StaffBaristaView showToast={showToast} />
        )}

        {/* STOKIS INVENTORY */}
        {activeTab === 'stokis_inventory' && (
          <StaffStokisView showToast={showToast} />
        )}

        {/* ATTENDANCE */}
        {activeTab === 'attendance' && (
          <AttendanceModule />
        )}

        {/* MEMBER */}
        {activeTab === 'member_portal' && (
          <MemberView showToast={showToast} />
        )}

        {/* GUEST */}
        {activeTab === 'guest_portal' && (
          <GuestView onRegisterMember={() => showToast('Pendaftaran Member baru dibuka!', 'info')} showToast={showToast} />
        )}
      </main>

      {/* Product Management Modal */}
      <ProductManagementModal
        isOpen={showProductModal}
        onClose={() => {
          setShowProductModal(false);
          setEditingProduct(null);
        }}
        initialProduct={editingProduct}
        categories={categories}
        onSave={(data) => {
          addMenuItem(data);
          showToast(`Menu "${data.name}" berhasil ditambahkan!`, 'success');
        }}
        onUpdate={(id, data) => {
          updateMenuItem(id, data);
          showToast('Menu berhasil diperbarui!', 'success');
        }}
        onAddCategory={(cat) => addCategory(cat)}
      />

      {/* Cash Movement Modal */}
      {showCashModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-stone-100">
              <h3 className="font-bold text-sm text-[#1F1E1D]">Mutasi Kas Laci Kasir</h3>
              <button onClick={() => setShowCashModal(false)} className="text-stone-400 hover:text-stone-700 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCashSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMutationType('KAS_KELUAR')}
                  className={`py-2 rounded-xl font-bold cursor-pointer transition ${
                    mutationType === 'KAS_KELUAR' ? 'bg-red-600 text-white shadow-xs' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  - Kas Keluar
                </button>
                <button
                  type="button"
                  onClick={() => setMutationType('KAS_MASUK')}
                  className={`py-2 rounded-xl font-bold cursor-pointer transition ${
                    mutationType === 'KAS_MASUK' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  + Kas Masuk
                </button>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Nominal (Rp)</label>
                <input
                  type="number"
                  required
                  min="1000"
                  step="1000"
                  value={mutationAmount}
                  onChange={(e) => setMutationAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono font-bold text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Kategori Mutasi</label>
                <select
                  value={mutationCategory}
                  onChange={(e) => setMutationCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden cursor-pointer"
                >
                  <option value="Beli Es Batu / Galon">Beli Es Batu / Galon</option>
                  <option value="Gas LPG / Galon">Gas LPG / Bahan Operasional</option>
                  <option value="Modal Awal Kasir">Modal Awal Kasir</option>
                  <option value="Tarik Tunai Bank">Tarik Tunai Bank</option>
                  <option value="Setor Omset Laci">Setor Omset Laci</option>
                  <option value="Lain-lain">Lain-lain</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Keterangan / Alasan</label>
                <input
                  type="text"
                  placeholder="Contoh: Es batu kristal 2 karung"
                  value={mutationNotes}
                  onChange={(e) => setMutationNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCashModal(false)}
                  className="px-3 py-2 rounded-xl text-stone-600 hover:bg-stone-100 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#4A2E1B] text-white rounded-xl font-bold cursor-pointer hover:bg-[#382213]"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printer Settings Modal */}
      {showPrinterModal && (
        <PrinterSettingsModal
          isOpen={showPrinterModal}
          onClose={() => setShowPrinterModal(false)}
          showToast={showToast}
        />
      )}

      {/* Platform Master: Add Tenant Modal */}
      {showAddTenantModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-5 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-sm text-stone-900">Registrasi Tenant Café Baru</h3>
                  <p className="text-[11px] text-stone-500">Buat entitas isolasi tenant & akun Owner pertama</p>
                </div>
              </div>
              <button onClick={() => setShowAddTenantModal(false)} className="text-stone-400 hover:text-stone-700 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            {tenantModalError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{tenantModalError}</span>
              </div>
            )}

            <form onSubmit={handleCreateTenantSubmit} className="space-y-4 text-xs">
              <div className="space-y-3">
                <h4 className="font-bold text-stone-700 uppercase tracking-wider text-[10px]">1. Informasi Café</h4>
                <div>
                  <label className="block font-semibold text-stone-600 mb-1">Nama Tenant Café *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Kopi Titik Temu"
                    value={tenantNameInput}
                    onChange={(e) => {
                      setTenantNameInput(e.target.value);
                      if (!tenantSlugInput) {
                        setTenantSlugInput(e.target.value.toLowerCase().replace(/[^a-z0-9]/g, '-'));
                      }
                    }}
                    className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-stone-600 mb-1">Pajak PB1 (%)</label>
                    <input
                      type="number"
                      value={taxRateInput}
                      onChange={(e) => setTaxRateInput(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-stone-600 mb-1">Biaya Layanan (%)</label>
                    <input
                      type="number"
                      value={serviceChargeInput}
                      onChange={(e) => setServiceChargeInput(e.target.value)}
                      className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono"
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-3 pt-2 border-t border-stone-100">
                <h4 className="font-bold text-stone-700 uppercase tracking-wider text-[10px]">2. Akun Owner Utama</h4>
                <div>
                  <label className="block font-semibold text-stone-600 mb-1">Nama Lengkap Owner *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Pratama Wicaksono"
                    value={ownerNameInput}
                    onChange={(e) => setOwnerNameInput(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-600 mb-1">Email Login Owner *</label>
                  <input
                    type="email"
                    required
                    placeholder="owner@titiktemu.id"
                    value={ownerEmailInput}
                    onChange={(e) => setOwnerEmailInput(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                  />
                </div>
                <div>
                  <label className="block font-semibold text-stone-600 mb-1">Password Sementara</label>
                  <input
                    type="text"
                    required
                    value={ownerPasswordInput}
                    onChange={(e) => setOwnerPasswordInput(e.target.value)}
                    className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-stone-100 flex justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddTenantModal(false)}
                  className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTenant}
                  className="px-5 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingTenant ? 'Mendaftarkan...' : 'Daftarkan Tenant & Owner'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
