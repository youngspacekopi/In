/**
 * KOPIIN — Real Production Application Interface
 * Full-screen, responsive, multi-role SaaS Café Management Platform
 * Runs natively on Mobile, Tablet, and Desktop without simulated phone bezels.
 */

import React, { useState, useEffect } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { PlatformMasterView } from '../roles/PlatformMasterView';
import { TenantOwnerView } from '../roles/TenantOwnerView';
import { TenantManagerView } from '../roles/TenantManagerView';
import { StaffCashierView } from '../roles/StaffCashierView';
import { StaffBaristaView } from '../roles/StaffBaristaView';
import { StaffStokisView } from '../roles/StaffStokisView';
import { MemberView } from '../roles/MemberView';
import { GuestView } from '../roles/GuestView';
import { AttendanceModule } from '../desktop/AttendanceModule';
import { FinancialReportsModule } from '../desktop/FinancialReportsModule';
import { ProductManagementModal } from '../desktop/ProductManagementModal';
import { PrinterSettingsModal } from '../common/PrinterSettingsModal';
import { OfflineIndicator } from '../common/OfflineIndicator';
import { PWAInstallButton } from '../common/PWAInstallButton';
import { StaffAttendanceView } from '../staff/StaffAttendanceView';
import { 
  Building2, 
  TrendingUp, 
  ShoppingBag, 
  Coffee, 
  Layers, 
  Boxes, 
  DollarSign, 
  Users, 
  FileSpreadsheet, 
  Award, 
  Printer, 
  Calendar, 
  Clock, 
  ShieldCheck, 
  Sparkles, 
  Plus, 
  X, 
  ChevronDown, 
  Info, 
  MoreHorizontal, 
  AlertCircle,
  UserCheck,
  LogOut,
  Camera
} from 'lucide-react';

interface Props {
  onOpenArchitectureModal?: () => void;
  showToast: (text: string, type?: 'success' | 'info' | 'error', description?: string) => void;
}

export const AndroidPresentation: React.FC<Props> = ({
  onOpenArchitectureModal,
  showToast,
}) => {
  const { 
    currentUser, 
    activeTenant, 
    tenants, 
    switchTenant, 
    registerTenant,
    logout
  } = usePlatform();

  const { 
    categories, 
    addMenuItem, 
    updateMenuItem, 
    addCategory, 
    addCashMovement,
    orders,
    inventory 
  } = useCafe();

  const role = currentUser.role;

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('default');
  const [showLogoutModal, setShowLogoutModal] = useState(false);

  // Sync tab when role changes
  useEffect(() => {
    switch (role) {
      case 'PLATFORM_MASTER':
        setActiveTab('tenants');
        break;
      case 'TENANT_OWNER':
        setActiveTab('overview');
        break;
      case 'TENANT_MANAGER':
        setActiveTab('shift');
        break;
      case 'STAFF_CASHIER':
      case 'STAFF_BARISTA':
      case 'STAFF_STOKIS':
        // Sesuai Permintaan: Khusus staf hanya aplikasi absensi dan laporan absen
        setActiveTab('absensi_app');
        break;
      case 'MEMBER':
        setActiveTab('member');
        break;
      case 'GUEST':
        setActiveTab('guest');
        break;
      default:
        setActiveTab('overview');
    }
  }, [role]);

  // Modals state
  const [showProductModal, setShowProductModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);

  const [showCashModal, setShowCashModal] = useState(false);
  const [mutationType, setMutationType] = useState<'KAS_MASUK' | 'KAS_KELUAR'>('KAS_KELUAR');
  const [mutationAmount, setMutationAmount] = useState<number>(50000);
  const [mutationCategory, setMutationCategory] = useState('Beli Es Batu / Galon');
  const [mutationNotes, setMutationNotes] = useState('');

  const [showPrinterModal, setShowPrinterModal] = useState(false);
  const [showMoreMenuModal, setShowMoreMenuModal] = useState(false);

  // Platform Master: Add Tenant Modal
  const [showAddTenantModal, setShowAddTenantModal] = useState(false);
  const [tenantNameInput, setTenantNameInput] = useState('');
  const [tenantSlugInput, setTenantSlugInput] = useState('');
  const [tenantLogoInput, setTenantLogoInput] = useState('https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=120&auto=format&fit=crop&q=80');
  const [ownerNameInput, setOwnerNameInput] = useState('');
  const [ownerEmailInput, setOwnerEmailInput] = useState('');
  const [ownerPasswordInput, setOwnerPasswordInput] = useState('KopiinOwner2026!');
  const [taxRateInput, setTaxRateInput] = useState('11');
  const [serviceChargeInput, setServiceChargeInput] = useState('5');
  const [isSubmittingTenant, setIsSubmittingTenant] = useState(false);
  const [tenantModalError, setTenantModalError] = useState<string | null>(null);

  const handleCreateTenantSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!tenantNameInput.trim() || !ownerEmailInput.trim() || !ownerNameInput.trim()) {
      setTenantModalError('Harap lengkapi nama café, nama owner, dan email owner.');
      return;
    }
    setTenantModalError(null);
    setIsSubmittingTenant(true);
    try {
      const slug = tenantSlugInput.trim() || tenantNameInput.toLowerCase().replace(/[^a-z0-9]/g, '-');
      const result = await registerTenant({
        tenantName: tenantNameInput.trim(),
        tenantSlug: slug,
        ownerFullName: ownerNameInput.trim(),
        ownerEmail: ownerEmailInput.trim(),
        ownerPasswordPlainText: ownerPasswordInput || 'KopiinOwner2026!',
        taxRate: parseFloat(taxRateInput) / 100 || 0.11,
        serviceCharge: parseFloat(serviceChargeInput) / 100 || 0.05,
        logoUrl: tenantLogoInput.trim() || undefined,
      });

      showToast(`Tenant "${result.tenant.name}" & Akun Owner (${result.owner.email}) berhasil dibuat!`, 'success');
      setShowAddTenantModal(false);
      setTenantNameInput('');
      setTenantSlugInput('');
      setOwnerNameInput('');
      setOwnerEmailInput('');
      setTenantLogoInput('https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=120&auto=format&fit=crop&q=80');
    } catch (err: any) {
      setTenantModalError(err?.message || 'Gagal mendaftarkan tenant.');
    } finally {
      setIsSubmittingTenant(false);
    }
  };

  const handleCashSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mutationAmount || mutationAmount <= 0) return;
    addCashMovement({
      movement_type: mutationType,
      category: mutationCategory,
      amount: Number(mutationAmount),
      notes: mutationNotes,
    });
    showToast(`Mutasi kas ${mutationType === 'KAS_MASUK' ? 'Masuk' : 'Keluar'} Rp${mutationAmount.toLocaleString('id-ID')} berhasil dicatat!`, 'success');
    setShowCashModal(false);
    setMutationNotes('');
  };

  // Role badges format
  const getRoleBadge = () => {
    switch (role) {
      case 'PLATFORM_MASTER':
        return { label: 'Platform Master', color: 'bg-purple-950 text-purple-200 border-purple-600' };
      case 'TENANT_OWNER':
        return { label: 'Owner Café', color: 'bg-amber-950 text-amber-200 border-amber-600' };
      case 'TENANT_MANAGER':
        return { label: 'Manager Café', color: 'bg-blue-950 text-blue-200 border-blue-600' };
      case 'STAFF_CASHIER':
        return { label: 'Staf Kasir (Absensi)', color: 'bg-teal-950 text-teal-200 border-teal-600' };
      case 'STAFF_BARISTA':
        return { label: 'Staf Barista (Absensi)', color: 'bg-emerald-950 text-emerald-200 border-emerald-600' };
      case 'STAFF_STOKIS':
        return { label: 'Staf Stokis (Absensi)', color: 'bg-indigo-950 text-indigo-200 border-indigo-600' };
      case 'MEMBER':
        return { label: 'Member VIP', color: 'bg-rose-950 text-rose-200 border-rose-600' };
      case 'GUEST':
        return { label: 'Tamu Café', color: 'bg-stone-800 text-stone-200 border-stone-600' };
      default:
        return { label: role, color: 'bg-stone-800 text-stone-200 border-stone-600' };
    }
  };

  const roleBadge = getRoleBadge();

  interface NavItem {
    id: string;
    label: string;
    icon: any;
    badge?: string | number | null;
  }

  // Navigation Items per Role for Desktop & Mobile
  const getNavItems = (): NavItem[] => {
    if (role === 'PLATFORM_MASTER') {
      return [
        { id: 'tenants', label: 'Tenant Café', icon: Building2 },
        { id: 'metrics', label: 'Metrik SaaS', icon: TrendingUp },
        { id: 'audit', label: 'Audit Trail', icon: Clock },
        { id: 'security', label: 'Keamanan RBAC', icon: ShieldCheck },
      ];
    }

    if (role === 'TENANT_OWNER') {
      const pendingOrdersCount = orders.filter(o => o.status === 'ACCEPTED' || o.status === 'IN_PROCESS').length;
      const lowStockCount = inventory.filter(i => i.status === 'LOW_STOCK').length;

      return [
        { id: 'overview', label: 'Ringkasan KPI', icon: TrendingUp, badge: null },
        { id: 'pos', label: 'Kasir POS', icon: ShoppingBag, badge: null },
        { id: 'kds', label: 'Kitchen KDS', icon: Coffee, badge: pendingOrdersCount > 0 ? pendingOrdersCount : null },
        { id: 'products', label: 'Menu & HPP', icon: Layers, badge: null },
        { id: 'inventory', label: 'Gudang Bahan', icon: Boxes, badge: lowStockCount > 0 ? '!' : null },
        { id: 'cashflow', label: 'Buku Kas Laci', icon: DollarSign, badge: null },
        { id: 'staff', label: 'Staf & Absensi', icon: Users, badge: null },
        { id: 'reports', label: 'Laba Rugi', icon: FileSpreadsheet, badge: null },
        { id: 'loyalty', label: 'Poin Member', icon: Award, badge: null },
      ];
    }

    if (role === 'TENANT_MANAGER') {
      return [
        { id: 'shift', label: 'Shift & Kas', icon: Clock },
        { id: 'tables', label: 'Denah Meja', icon: Layers },
        { id: 'pos', label: 'Kasir POS', icon: ShoppingBag },
        { id: 'voids', label: 'Persetujuan Void', icon: ShieldCheck },
        { id: 'attendance', label: 'Absensi Staf', icon: Calendar },
      ];
    }

    // KHUSUS AKUN STAFF (CASHIER, BARISTA, STOKIS):
    // Sesuai instruksi: HANYA ADA aplikasi absensi dan laporan absen!
    if (role === 'STAFF_CASHIER' || role === 'STAFF_BARISTA' || role === 'STAFF_STOKIS') {
      return [
        { id: 'absensi_app', label: 'Aplikasi Absensi', icon: Camera },
        { id: 'absensi_laporan', label: 'Laporan Absen', icon: FileSpreadsheet },
      ];
    }

    if (role === 'MEMBER') {
      return [
        { id: 'member', label: 'Kartu Member & Poin', icon: Sparkles },
        { id: 'menu', label: 'Katalog Menu', icon: Coffee },
      ];
    }

    if (role === 'GUEST') {
      return [
        { id: 'guest', label: 'Buku Menu Digital', icon: Coffee },
      ];
    }

    return [];
  };

  const navItems = getNavItems();

  return (
    <div className="min-h-screen bg-[#FDFBF7] text-stone-900 flex flex-col w-full selection:bg-amber-500 selection:text-white">
      {/* Top Application Header Bar */}
      <header className="sticky top-0 z-40 bg-[#4A2E1B] text-white shadow-md px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Active Café Outlet */}
        <div className="flex items-center gap-2.5 min-w-0">
          {activeTenant?.logo_url ? (
            <img
              src={activeTenant.logo_url}
              alt={activeTenant.name}
              className="w-8 h-8 rounded-xl object-cover border border-amber-500/40 shadow-xs shrink-0"
            />
          ) : (
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 font-black text-xs flex items-center justify-center shadow-xs shrink-0">
              {activeTenant?.name?.charAt(0) || 'K'}
            </div>
          )}
          <div className="min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              {tenants.length > 1 ? (
                <div className="flex items-center gap-1 bg-black/20 px-2 py-0.5 rounded-lg border border-amber-600/40">
                  <Building2 className="w-3.5 h-3.5 text-amber-300 shrink-0" />
                  <select
                    value={activeTenant?.id}
                    onChange={(e) => switchTenant(e.target.value)}
                    className="bg-transparent text-white font-extrabold text-xs outline-none cursor-pointer truncate max-w-[150px] sm:max-w-[200px]"
                  >
                    {tenants.map((t) => (
                      <option key={t.id} value={t.id} className="bg-stone-900 text-white">
                        {t.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-3 h-3 text-amber-300 shrink-0" />
                </div>
              ) : (
                <h1 className="font-extrabold text-xs sm:text-sm text-white leading-tight truncate">
                  {activeTenant?.name || 'KOPIIN Café'}
                </h1>
              )}
              <span className="hidden md:inline-block text-[10px] font-mono text-amber-200/80 bg-white/10 px-2 py-0.5 rounded-md">
                PB1: {((activeTenant?.settings?.tax_rate || 0.11) * 100)}% | Servis: {((activeTenant?.settings?.service_charge || 0.05) * 100)}%
              </span>
            </div>
            <p className="text-[10px] text-amber-200/90 truncate mt-0.5">
              Operator: <strong className="text-white font-bold">{currentUser.full_name}</strong>
            </p>
          </div>
        </div>

        {/* Action Controls: User Role Badge, Logout & Utilities */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Static Isolated User Role Badge (Role switcher removed inside app) */}
          <div
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-[11px] sm:text-xs font-extrabold shadow-xs select-none ${roleBadge.color}`}
            title={`Akun: ${currentUser.full_name} (${roleBadge.label})`}
          >
            <UserCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate max-w-[110px] sm:max-w-none">{roleBadge.label}</span>
          </div>

          {/* Logout Button */}
          <button
            onClick={() => setShowLogoutModal(true)}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-red-950/80 hover:bg-red-900 border border-red-700/60 text-red-200 text-[11px] sm:text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
            title="Keluar dari Akun (Logout)"
          >
            <LogOut className="w-3.5 h-3.5 text-red-400" />
            <span className="hidden sm:inline">Keluar</span>
          </button>

          {/* Quick Thermal Printer Settings */}
          <button
            onClick={() => setShowPrinterModal(true)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 transition cursor-pointer flex items-center gap-1 text-xs"
            title="Pengaturan Hardware Printer POS"
          >
            <Printer className="w-4 h-4 text-amber-300" />
            <span className="hidden lg:inline text-[11px] font-bold">Printer</span>
          </button>

          {/* Specs / Architecture */}
          {onOpenArchitectureModal && (
            <button
              onClick={onOpenArchitectureModal}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-stone-200 transition cursor-pointer"
              title="Spesifikasi Arsitektur SaaS KOPIIN"
            >
              <Info className="w-4 h-4" />
            </button>
          )}

          <OfflineIndicator />
          <PWAInstallButton compact />
        </div>
      </header>

      {/* Desktop/Tablet Horizontal Navigation Bar */}
      <nav className="hidden sm:flex bg-white border-b border-stone-200 px-4 sm:px-6 py-2 overflow-x-auto gap-1.5 shadow-2xs sticky top-[53px] z-30">
        {navItems.map((it) => {
          const Icon = it.icon;
          const isActive = activeTab === it.id;
          return (
            <button
              key={it.id}
              onClick={() => setActiveTab(it.id)}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer relative ${
                isActive
                  ? 'bg-[#4A2E1B] text-white shadow-xs'
                  : 'text-stone-600 hover:text-stone-950 hover:bg-stone-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{it.label}</span>
              {it.badge && (
                <span className="w-4 h-4 rounded-full bg-red-600 text-white text-[9px] font-bold flex items-center justify-center">
                  {it.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Main Workspace Frame */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-3.5 sm:p-6 pb-24 sm:pb-10 space-y-5">
        {/* PLATFORM MASTER */}
        {role === 'PLATFORM_MASTER' && (
          <PlatformMasterView
            defaultTab={activeTab as any}
            onOpenAddTenant={() => setShowAddTenantModal(true)}
            showToast={showToast}
          />
        )}

        {/* TENANT OWNER */}
        {role === 'TENANT_OWNER' && (
          <>
            {activeTab === 'overview' && (
              <TenantOwnerView
                defaultTab="overview"
                onOpenNewProduct={() => {
                  setEditingProduct(null);
                  setShowProductModal(true);
                }}
                onOpenCashModal={() => setShowCashModal(true)}
                showToast={showToast}
              />
            )}
            {activeTab === 'pos' && (
              <StaffCashierView showToast={showToast} />
            )}
            {activeTab === 'kds' && (
              <StaffBaristaView showToast={showToast} />
            )}
            {activeTab === 'products' && (
              <TenantOwnerView
                defaultTab="products"
                onOpenNewProduct={() => {
                  setEditingProduct(null);
                  setShowProductModal(true);
                }}
                onOpenCashModal={() => setShowCashModal(true)}
                showToast={showToast}
              />
            )}
            {activeTab === 'inventory' && (
              <StaffStokisView showToast={showToast} />
            )}
            {activeTab === 'cashflow' && (
              <TenantOwnerView
                defaultTab="cashflow"
                onOpenNewProduct={() => {
                  setEditingProduct(null);
                  setShowProductModal(true);
                }}
                onOpenCashModal={() => setShowCashModal(true)}
                showToast={showToast}
              />
            )}
            {activeTab === 'staff' && (
              <TenantOwnerView
                defaultTab="staff"
                onOpenNewProduct={() => {
                  setEditingProduct(null);
                  setShowProductModal(true);
                }}
                onOpenCashModal={() => setShowCashModal(true)}
                showToast={showToast}
              />
            )}
            {activeTab === 'reports' && (
              <FinancialReportsModule />
            )}
            {activeTab === 'loyalty' && (
              <TenantOwnerView
                defaultTab="loyalty"
                onOpenNewProduct={() => {
                  setEditingProduct(null);
                  setShowProductModal(true);
                }}
                onOpenCashModal={() => setShowCashModal(true)}
                showToast={showToast}
              />
            )}
          </>
        )}

        {/* TENANT MANAGER */}
        {role === 'TENANT_MANAGER' && (
          <>
            {activeTab === 'shift' && (
              <TenantManagerView defaultTab="shift" showToast={showToast} />
            )}
            {activeTab === 'tables' && (
              <TenantManagerView defaultTab="tables" showToast={showToast} />
            )}
            {activeTab === 'pos' && (
              <StaffCashierView showToast={showToast} />
            )}
            {activeTab === 'voids' && (
              <TenantManagerView defaultTab="voids" showToast={showToast} />
            )}
            {activeTab === 'attendance' && (
              <TenantManagerView defaultTab="attendance" showToast={showToast} />
            )}
          </>
        )}

        {/* KHUSUS AKUN STAFF (STAFF_CASHIER, STAFF_BARISTA, STAFF_STOKIS) */}
        {/* Sesuai Permintaan: Khusus akun staff, HANYA ADA aplikasi absensi dan laporan absen */}
        {(role === 'STAFF_CASHIER' || role === 'STAFF_BARISTA' || role === 'STAFF_STOKIS') && (
          <StaffAttendanceView
            activeTab={activeTab === 'absensi_laporan' ? 'absensi_laporan' : 'absensi_app'}
            onTabChange={(newTab) => setActiveTab(newTab)}
            showToast={showToast}
          />
        )}

        {/* MEMBER */}
        {role === 'MEMBER' && (
          <>
            {activeTab === 'member' && (
              <MemberView showToast={showToast} />
            )}
            {activeTab === 'menu' && (
              <GuestView showToast={showToast} />
            )}
          </>
        )}

        {/* GUEST */}
        {role === 'GUEST' && (
          <GuestView showToast={showToast} />
        )}
      </main>

      {/* Mobile Fixed Bottom Navigation Bar (Screens < 640px) */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-stone-200 text-stone-600 px-1 py-1 flex items-center justify-around shadow-lg">
        {navItems.slice(0, 4).map((it) => {
          const Icon = it.icon;
          const isActive = activeTab === it.id;
          return (
            <button
              key={it.id}
              onClick={() => setActiveTab(it.id)}
              className="flex-1 flex flex-col items-center justify-center py-1 transition cursor-pointer relative"
            >
              <div
                className={`w-10 h-7 rounded-xl flex items-center justify-center transition-all ${
                  isActive ? 'bg-[#4A2E1B] text-white shadow-xs' : 'text-stone-500'
                }`}
              >
                <Icon className="w-4 h-4" />
                {it.badge && (
                  <span className="absolute -top-0.5 right-2 w-3.5 h-3.5 rounded-full bg-red-600 text-white text-[8px] font-bold flex items-center justify-center">
                    {it.badge}
                  </span>
                )}
              </div>
              <span className={`text-[10px] mt-0.5 font-bold transition-all truncate max-w-[65px] ${
                isActive ? 'text-[#4A2E1B]' : 'text-stone-500'
              }`}>
                {it.label.split(' ')[0]}
              </span>
            </button>
          );
        })}

        {/* More Menu button for roles with > 4 items */}
        {navItems.length > 4 && (
          <button
            onClick={() => setShowMoreMenuModal(true)}
            className="flex-1 flex flex-col items-center justify-center py-1 transition cursor-pointer"
          >
            <div className="w-10 h-7 rounded-xl flex items-center justify-center text-stone-500 hover:text-stone-800">
              <MoreHorizontal className="w-4 h-4" />
            </div>
            <span className="text-[10px] mt-0.5 font-bold text-stone-500">
              Lainnya
            </span>
          </button>
        )}
      </nav>

      {/* Mobile "Lainnya" Hub Menu Modal */}
      {showMoreMenuModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs z-50 flex flex-col justify-end items-center sm:p-4">
          <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-5 space-y-4 shadow-2xl animate-in slide-in-from-bottom-5">
            <div className="w-12 h-1 bg-stone-300 rounded-full mx-auto sm:hidden" />
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <div>
                <h3 className="font-extrabold text-sm text-[#1F1E1D]">Menu Operasional Café</h3>
                <p className="text-[11px] text-stone-500">Pilih modul kerja yang ingin diakses</p>
              </div>
              <button onClick={() => setShowMoreMenuModal(false)} className="p-1 rounded-full hover:bg-stone-100 text-stone-400">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2.5 text-xs">
              {navItems.slice(4).map((it) => {
                const Icon = it.icon;
                return (
                  <button
                    key={it.id}
                    onClick={() => {
                      setActiveTab(it.id);
                      setShowMoreMenuModal(false);
                    }}
                    className="p-3 bg-stone-50 hover:bg-amber-50 rounded-2xl border border-stone-200 text-left flex items-start gap-2.5 transition cursor-pointer"
                  >
                    <div className="w-8 h-8 rounded-xl bg-[#4A2E1B] text-white flex items-center justify-center shrink-0">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="font-bold text-stone-900 truncate">{it.label}</h4>
                      <p className="text-[10px] text-stone-500">Akses modul</p>
                    </div>
                  </button>
                );
              })}

              <button
                onClick={() => {
                  setShowMoreMenuModal(false);
                  setShowPrinterModal(true);
                }}
                className="p-3 bg-stone-50 hover:bg-amber-50 rounded-2xl border border-stone-200 text-left flex items-start gap-2.5 transition cursor-pointer"
              >
                <div className="w-8 h-8 rounded-xl bg-stone-700 text-white flex items-center justify-center shrink-0">
                  <Printer className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900">Printer Thermal</h4>
                  <p className="text-[10px] text-stone-500">Bluetooth & Serial USB</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Product Management Modal */}
      <ProductManagementModal
        isOpen={showProductModal}
        onClose={() => {
          setShowProductModal(false);
          setEditingProduct(null);
        }}
        initialProduct={editingProduct}
        categories={categories}
        onSave={(data) => {
          addMenuItem(data);
          showToast(`Menu "${data.name}" berhasil dibuat!`, 'success');
        }}
        onUpdate={(id, data) => {
          updateMenuItem(id, data);
          showToast('Menu berhasil diperbarui!', 'success');
        }}
        onAddCategory={(cat) => addCategory(cat)}
      />

      {/* Printer Settings Modal */}
      {showPrinterModal && (
        <PrinterSettingsModal
          isOpen={showPrinterModal}
          onClose={() => setShowPrinterModal(false)}
          showToast={showToast}
        />
      )}

      {/* Mutasi Kas Laci Modal */}
      {showCashModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-sm rounded-2xl p-5 shadow-2xl border border-stone-200 space-y-4">
            <div className="flex justify-between items-center pb-2 border-b border-stone-100">
              <h3 className="font-bold text-sm text-[#1F1E1D]">Mutasi Kas Laci Kasir</h3>
              <button onClick={() => setShowCashModal(false)} className="text-stone-400 hover:text-stone-700 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handleCashSubmit} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setMutationType('KAS_KELUAR')}
                  className={`py-2 rounded-xl font-bold cursor-pointer transition ${
                    mutationType === 'KAS_KELUAR' ? 'bg-red-600 text-white shadow-xs' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  - Kas Keluar
                </button>
                <button
                  type="button"
                  onClick={() => setMutationType('KAS_MASUK')}
                  className={`py-2 rounded-xl font-bold cursor-pointer transition ${
                    mutationType === 'KAS_MASUK' ? 'bg-emerald-600 text-white shadow-xs' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  + Kas Masuk
                </button>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Nominal (Rp)</label>
                <input
                  type="number"
                  required
                  min="1000"
                  step="1000"
                  value={mutationAmount}
                  onChange={(e) => setMutationAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl font-mono font-bold text-sm focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Kategori Mutasi</label>
                <select
                  value={mutationCategory}
                  onChange={(e) => setMutationCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden cursor-pointer"
                >
                  <option value="Beli Es Batu / Galon">Beli Es Batu / Galon</option>
                  <option value="Gas LPG / Galon">Gas LPG / Bahan Operasional</option>
                  <option value="Modal Awal Kasir">Modal Awal Kasir</option>
                  <option value="Tarik Tunai Bank">Tarik Tunai Bank</option>
                  <option value="Setor Omset Laci">Setor Omset Laci</option>
                  <option value="Lain-lain">Lain-lain</option>
                </select>
              </div>

              <div>
                <label className="block text-stone-500 mb-1 font-semibold">Keterangan / Alasan</label>
                <input
                  type="text"
                  placeholder="Contoh: Es batu kristal 2 karung"
                  value={mutationNotes}
                  onChange={(e) => setMutationNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowCashModal(false)}
                  className="px-3 py-2 rounded-xl text-stone-600 hover:bg-stone-100 cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-[#4A2E1B] text-white rounded-xl font-bold cursor-pointer hover:bg-[#382213]"
                >
                  Simpan Catatan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Platform Master: Add Tenant Modal */}
      {showAddTenantModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-sm w-full p-5 shadow-2xl border border-stone-200 space-y-4 animate-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
                  <Building2 className="w-4 h-4" />
                </div>
                <h3 className="font-extrabold text-xs text-stone-900">Tambah Tenant Café</h3>
              </div>
              <button onClick={() => setShowAddTenantModal(false)} className="text-stone-400 hover:text-stone-700 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            {tenantModalError && (
              <div className="p-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-[11px] flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                <span>{tenantModalError}</span>
              </div>
            )}

            <form onSubmit={handleCreateTenantSubmit} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-stone-600 mb-1">Nama Tenant Café *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Titik Temu Café"
                  value={tenantNameInput}
                  onChange={(e) => setTenantNameInput(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-600 mb-1">Logo Tenant Café (URL Gambar)</label>
                <div className="flex items-center gap-2 mb-1.5">
                  <img
                    src={tenantLogoInput || 'https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=120&auto=format&fit=crop&q=80'}
                    alt="Logo Preview"
                    className="w-9 h-9 rounded-xl object-cover border border-stone-300 shrink-0 bg-stone-100"
                  />
                  <input
                    type="url"
                    placeholder="https://... (URL logo café)"
                    value={tenantLogoInput}
                    onChange={(e) => setTenantLogoInput(e.target.value)}
                    className="flex-1 px-3 py-2 border border-stone-300 rounded-xl text-[11px] focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-mono"
                  />
                </div>
                {/* Preset logo choices */}
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[10px] text-stone-400">Pilihan Cepat:</span>
                  <button
                    type="button"
                    onClick={() => setTenantLogoInput('https://images.unsplash.com/photo-1554118811-1e0d58224f24?w=120&auto=format&fit=crop&q=80')}
                    className="text-[10px] px-2 py-0.5 rounded-lg bg-stone-100 hover:bg-purple-100 text-stone-700 cursor-pointer"
                  >
                    Modern Brown
                  </button>
                  <button
                    type="button"
                    onClick={() => setTenantLogoInput('https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=120&auto=format&fit=crop&q=80')}
                    className="text-[10px] px-2 py-0.5 rounded-lg bg-stone-100 hover:bg-purple-100 text-stone-700 cursor-pointer"
                  >
                    Dark Roastery
                  </button>
                  <button
                    type="button"
                    onClick={() => setTenantLogoInput('https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=120&auto=format&fit=crop&q=80')}
                    className="text-[10px] px-2 py-0.5 rounded-lg bg-stone-100 hover:bg-purple-100 text-stone-700 cursor-pointer"
                  >
                    Minimalist Latte
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-600 mb-1">Nama Lengkap Owner *</label>
                <input
                  type="text"
                  required
                  placeholder="Nama pemilik utama"
                  value={ownerNameInput}
                  onChange={(e) => setOwnerNameInput(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-600 mb-1">Email Login Owner *</label>
                <input
                  type="email"
                  required
                  placeholder="owner@titiktemu.id"
                  value={ownerEmailInput}
                  onChange={(e) => setOwnerEmailInput(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block font-semibold text-stone-600 mb-1">Kata Sandi Akun Owner *</label>
                <input
                  type="text"
                  required
                  value={ownerPasswordInput}
                  onChange={(e) => setOwnerPasswordInput(e.target.value)}
                  className="w-full px-3 py-2 border border-stone-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:outline-hidden font-mono"
                />
              </div>

              <div className="p-2.5 bg-purple-50 rounded-xl border border-purple-200 text-[10px] text-purple-900 leading-snug">
                <strong>Ketentuan Multi-Owner:</strong> Tenant ini dapat memiliki lebih dari 3 akun owner (tanpa batas). Owner tambahan dapat didaftarkan kapan saja oleh Master maupun Owner melalui menu Staf.
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddTenantModal(false)}
                  className="px-3 py-2 rounded-xl text-stone-600 hover:bg-stone-100 font-semibold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  disabled={isSubmittingTenant}
                  className="px-4 py-2 bg-purple-700 hover:bg-purple-800 text-white rounded-xl font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
                >
                  {isSubmittingTenant ? 'Mendaftarkan...' : 'Daftarkan'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Logout Confirmation Modal */}
      {showLogoutModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl text-stone-900">
            <div className="flex items-center justify-between pb-2 border-b border-stone-100">
              <h3 className="font-black text-base text-stone-900 flex items-center gap-2">
                <LogOut className="w-5 h-5 text-red-600" />
                <span>Konfirmasi Logout</span>
              </h3>
              <button onClick={() => setShowLogoutModal(false)} className="text-stone-400 hover:text-stone-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-stone-600 leading-relaxed">
              Apakah Anda yakin ingin keluar dari akun <strong>{currentUser.full_name}</strong> ({roleBadge.label})? Anda akan diarahkan kembali ke halaman login.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutModal(false)}
                className="px-4 py-2 rounded-xl text-stone-600 hover:bg-stone-100 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutModal(false);
                  logout();
                  showToast('Berhasil Keluar', 'info', 'Sesi operasional Anda telah diakhiri.');
                }}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-extrabold shadow-md cursor-pointer transition active:scale-95 flex items-center gap-1.5"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Ya, Keluar Akun</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
