/**
 * KOPIIN — Tablet Presentation (1024px Landscape POS Console)
 * Designed for on-counter Android/iPad POS tablets:
 * - Kasir POS Billing Terminal
 * - Barista Kitchen Display System (KDS)
 * - Supervisor Meja & Void Approval
 * - Stokis Opname
 * - Absensi Selfie Karyawan
 */

import React, { useState, useEffect } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { useCafe } from '../../context/CafeContext';
import { StaffCashierView } from '../roles/StaffCashierView';
import { StaffBaristaView } from '../roles/StaffBaristaView';
import { StaffStokisView } from '../roles/StaffStokisView';
import { TenantManagerView } from '../roles/TenantManagerView';
import { TenantOwnerView } from '../roles/TenantOwnerView';
import { AttendanceModule } from '../desktop/AttendanceModule';
import { 
  Tablet, 
  ShoppingBag, 
  Coffee, 
  Calendar, 
  TrendingUp, 
  Boxes, 
  Layers, 
  ShieldCheck 
} from 'lucide-react';

interface Props {
  showToast: (text: string, type?: 'success' | 'info' | 'error') => void;
}

export const TabletPresentation: React.FC<Props> = ({ showToast }) => {
  const { currentUser, activeTenant } = usePlatform();
  const role = currentUser.role;

  const [tab, setTab] = useState<string>('pos');

  useEffect(() => {
    if (role === 'STAFF_BARISTA') {
      setTab('kds');
    } else if (role === 'STAFF_STOKIS') {
      setTab('inventory');
    } else {
      setTab('pos');
    }
  }, [role]);

  return (
    <div className="bg-stone-900 min-h-screen p-4 flex items-center justify-center">
      {/* Tablet Landscape Frame Simulation (1024px) */}
      <div className="w-full max-w-[1024px] bg-[#FDFBF7] rounded-3xl shadow-2xl border-4 border-stone-800 overflow-hidden flex flex-col min-h-[680px]">
        {/* Tablet Top Navigation Bar */}
        <div className="px-5 py-3 bg-[#4A2E1B] text-white flex items-center justify-between shadow-xs shrink-0 flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <Tablet className="w-5 h-5 text-amber-400" />
            <div>
              <h2 className="font-extrabold text-sm text-white leading-tight">
                {activeTenant?.name || 'KOPIIN Café'} Tablet POS
              </h2>
              <span className="text-[10px] text-amber-200 font-mono">
                Operator: {currentUser.full_name} ({currentUser.role})
              </span>
            </div>
          </div>

          {/* Quick Tablet Tabs */}
          <div className="flex items-center gap-1.5 bg-black/20 p-1 rounded-xl flex-wrap">
            {(role === 'STAFF_CASHIER' || role === 'TENANT_OWNER' || role === 'TENANT_MANAGER') && (
              <button
                onClick={() => setTab('pos')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  tab === 'pos' ? 'bg-white text-[#4A2E1B] shadow-xs' : 'text-stone-300 hover:text-white'
                }`}
              >
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>Kasir POS</span>
              </button>
            )}

            {(role === 'STAFF_BARISTA' || role === 'TENANT_OWNER' || role === 'TENANT_MANAGER') && (
              <button
                onClick={() => setTab('kds')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  tab === 'kds' ? 'bg-white text-[#4A2E1B] shadow-xs' : 'text-stone-300 hover:text-white'
                }`}
              >
                <Coffee className="w-3.5 h-3.5" />
                <span>Barista KDS</span>
              </button>
            )}

            {(role === 'TENANT_MANAGER' || role === 'TENANT_OWNER') && (
              <button
                onClick={() => setTab('tables')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  tab === 'tables' ? 'bg-white text-[#4A2E1B] shadow-xs' : 'text-stone-300 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Meja Café</span>
              </button>
            )}

            {(role === 'STAFF_STOKIS' || role === 'TENANT_OWNER') && (
              <button
                onClick={() => setTab('inventory')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  tab === 'inventory' ? 'bg-white text-[#4A2E1B] shadow-xs' : 'text-stone-300 hover:text-white'
                }`}
              >
                <Boxes className="w-3.5 h-3.5" />
                <span>Gudang</span>
              </button>
            )}

            {role !== 'MEMBER' && role !== 'GUEST' && role !== 'PLATFORM_MASTER' && (
              <button
                onClick={() => setTab('attendance')}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
                  tab === 'attendance' ? 'bg-white text-[#4A2E1B] shadow-xs' : 'text-stone-300 hover:text-white'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Absensi Selfie</span>
              </button>
            )}
          </div>
        </div>

        {/* Workspace */}
        <div className="flex-1 p-5 overflow-y-auto">
          {tab === 'pos' && <StaffCashierView showToast={showToast} />}
          {tab === 'kds' && <StaffBaristaView showToast={showToast} />}
          {tab === 'tables' && <TenantManagerView defaultTab="tables" showToast={showToast} />}
          {tab === 'inventory' && <StaffStokisView showToast={showToast} />}
          {tab === 'attendance' && <AttendanceModule />}
        </div>
      </div>
    </div>
  );
};
