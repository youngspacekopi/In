/**
 * KOPIIN — Native Authentication & Login Page
 * Sesuai Permintaan User:
 * 1. Halaman login adalah tampilan awal ketika membuka aplikasi
 * 2. Halaman login TIDAK ADA fitur daftar (No register/sign-up)
 * 3. Akses cepat perpindahan akun demo HANYA di halaman login
 * 4. Setiap akun terisolasi dan otomatis masuk ke permissions masing-masing
 */

import React, { useState } from 'react';
import { usePlatform } from '../../context/PlatformContext';
import { UserRole } from '../../types/platform';
import { 
  Coffee, 
  Lock, 
  Mail, 
  Eye, 
  EyeOff, 
  ArrowRight, 
  ShieldCheck, 
  Users, 
  Sparkles, 
  Building2, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  HelpCircle,
  ShoppingBag,
  Boxes
} from 'lucide-react';

interface Props {
  showToast: (text: string, type?: 'success' | 'info' | 'error', description?: string) => void;
}

export const LoginPage: React.FC<Props> = ({ showToast }) => {
  const { loginWithCredentials, loginAsRole } = usePlatform();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Form submit handler
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!identifier.trim()) {
      setErrorMessage('Silakan masukkan email atau username akun Anda.');
      return;
    }
    setErrorMessage(null);
    setIsLoading(true);

    try {
      const res = await loginWithCredentials(identifier.trim(), password);
      if (res.success) {
        showToast('Berhasil Masuk!', 'success', 'Sesi operasional café telah aktif.');
      } else {
        setErrorMessage(res.error || 'Gagal masuk ke sistem.');
        showToast('Gagal Masuk', 'error', res.error || 'Periksa kembali data login Anda.');
      }
    } catch (err: any) {
      setErrorMessage(err?.message || 'Terjadi kesalahan sistem saat otentikasi.');
    } finally {
      setIsLoading(false);
    }
  };

  // Quick Demo Account Login handler
  const handleQuickDemoLogin = (role: UserRole, roleName: string) => {
    setIsLoading(true);
    try {
      loginAsRole(role);
      showToast(
        `Masuk sebagai ${roleName}`,
        'success',
        `Hak akses dan antarmuka telah disesuaikan secara terisolasi.`
      );
    } finally {
      setIsLoading(false);
    }
  };

  const demoAccounts: {
    role: UserRole;
    title: string;
    name: string;
    email: string;
    badge: string;
    badgeColor: string;
    desc: string;
    icon: any;
    note?: string;
  }[] = [
    {
      role: 'TENANT_OWNER',
      title: 'Owner Café',
      name: 'Arya Pratama',
      email: 'owner@youngspace.cafe',
      badge: 'Full Owner',
      badgeColor: 'bg-amber-100 text-amber-900 border-amber-300',
      desc: 'Owner Young Space: Ringkasan KPI Finansial, Laba Rugi, POS Kasir, Kitchen KDS, HPP & Stok, Manajemen Staf.',
      icon: Coffee,
    },
    {
      role: 'TENANT_MANAGER',
      title: 'Manager Operasional',
      name: 'Dian Permata',
      email: 'manager@youngspace.cafe',
      badge: 'Supervisor',
      badgeColor: 'bg-blue-100 text-blue-900 border-blue-300',
      desc: 'Buka/Tutup Shift Kasir, Denah Meja, Otorisasi Void Tagihan, Monitoring Absensi Staf.',
      icon: Users,
    },
    {
      role: 'STAFF_CASHIER',
      title: 'Staf Kasir',
      name: 'Budi Santoso',
      email: 'cashier@youngspace.cafe',
      badge: 'Kasir POS & Transaksi',
      badgeColor: 'bg-teal-100 text-teal-900 border-teal-300',
      desc: 'Terminal kasir POS: Buka order dine-in & takeaway, split bill, payment QRIS/Cash/Kartu, cetak struk thermal, dan closing kasir.',
      icon: ShoppingBag,
    },
    {
      role: 'STAFF_BARISTA',
      title: 'Staf Barista',
      name: 'Rian Wijaya',
      email: 'barista@youngspace.cafe',
      badge: 'Kitchen Barista (KDS)',
      badgeColor: 'bg-emerald-100 text-emerald-900 border-emerald-300',
      desc: 'Kitchen Display System (KDS): Antrean tiket pesanan racikan kopi/non-kopi, timer penyajian, update status KDS real-time.',
      icon: Coffee,
    },
    {
      role: 'STAFF_STOKIS',
      title: 'Staf Stokis / Gudang',
      name: 'Hendra Setiawan',
      email: 'stokis@youngspace.cafe',
      badge: 'Gudang & Bahan Baku',
      badgeColor: 'bg-indigo-100 text-indigo-900 border-indigo-300',
      desc: 'Manajemen logistik gudang: Kartu stok bahan baku, stok opname harian, restock bahan, dan histori mutasi barang.',
      icon: Boxes,
    },
    {
      role: 'STAFF',
      title: 'Staf Karyawan (Umum)',
      name: 'Maya Anggraini',
      email: 'staff@youngspace.cafe',
      badge: 'Khusus Absensi & Laporan',
      badgeColor: 'bg-purple-100 text-purple-900 border-purple-300',
      desc: 'Role staf operasional umum: Khusus fitur absensi selfie masuk/pulang dengan kamera & GPS, serta laporan riwayat absensi.',
      icon: Clock,
      note: 'Hanya Absensi & Laporan Absen',
    },
    {
      role: 'MEMBER',
      title: 'Member Pelanggan VIP',
      name: 'Siti Rahma',
      email: 'member@gmail.com',
      badge: 'VIP Gold',
      badgeColor: 'bg-rose-100 text-rose-900 border-rose-300',
      desc: 'Portal pelanggan: Kartu digital member, cek saldo poin loyalitas, katalog menu favorit.',
      icon: Sparkles,
    },
    {
      role: 'GUEST',
      title: 'Pelanggan Tamu (Walk-In)',
      name: 'Tamu Café',
      email: 'guest@session.local',
      badge: 'Walk-In',
      badgeColor: 'bg-stone-200 text-stone-800 border-stone-300',
      desc: 'Katalog buku menu digital mandiri dengan filtering kategori dan info alergen.',
      icon: Coffee,
    },
  ];

  return (
    <div className="min-h-screen bg-[#1F1E1D] text-stone-100 flex flex-col justify-between selection:bg-amber-600 selection:text-white">
      {/* Background Ambience Pattern */}
      <div className="fixed inset-0 pointer-events-none opacity-5 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:20px_20px]" />

      {/* Main Centered Authentication Container */}
      <main className="relative z-10 flex-1 max-w-4xl mx-auto w-full px-4 py-8 sm:py-12 flex flex-col items-center justify-center">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-3xl bg-amber-500 text-stone-950 shadow-xl shadow-amber-500/20 mb-3.5 transform transition hover:rotate-6">
            <Coffee className="w-8 h-8 stroke-[2.5]" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center justify-center gap-2">
            <span>KOPIIN</span>
            <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
              Point of Sale & Café SaaS
            </span>
          </h1>
          <p className="text-xs sm:text-sm text-stone-400 mt-1 max-w-md mx-auto">
            Sistem Manajemen Multi-Tenant Kafe Terpadu — Masuk untuk mengakses ruang kerja peran Anda.
          </p>
        </div>

        {/* Login Form Box */}
        <div className="w-full max-w-md bg-[#2C2B29] border border-stone-700/60 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          <div className="border-b border-stone-700/60 pb-4">
            <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              <span>Masuk ke Akun Anda</span>
            </h2>
            <p className="text-xs text-stone-400 mt-0.5">
              Gunakan email/username akun yang terdaftar di kafe
            </p>
          </div>

          {errorMessage && (
            <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-800 text-red-200 text-xs flex items-start gap-2.5 animate-in fade-in duration-200">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="flex-1 font-medium">{errorMessage}</div>
            </div>
          )}

          <form onSubmit={handleLoginSubmit} className="space-y-4">
            {/* Input Email / Username */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-stone-300">
                Email atau Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="Contoh: owner@youngspace.cafe atau kasir"
                  className="w-full pl-10 pr-3.5 py-3 rounded-2xl bg-stone-900 border border-stone-700 text-white placeholder-stone-500 text-xs sm:text-sm focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                  autoComplete="username"
                  required
                />
              </div>
            </div>

            {/* Input Password */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-xs font-bold text-stone-300">
                  Kata Sandi
                </label>
                <span className="text-[10px] text-stone-400">
                  (Default demo: bebas)
                </span>
              </div>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-stone-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Masukkan kata sandi..."
                  className="w-full pl-10 pr-10 py-3 rounded-2xl bg-stone-900 border border-stone-700 text-white placeholder-stone-500 text-xs sm:text-sm focus:border-amber-500 focus:outline-none focus:ring-1 focus:ring-amber-500 transition"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-stone-500 hover:text-stone-300 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-3.5 px-4 rounded-2xl bg-[#4A2E1B] hover:bg-[#5C3922] active:bg-[#3D2616] text-amber-200 font-extrabold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-black/40 border border-amber-600/40 transition active:scale-[0.99] cursor-pointer disabled:opacity-50"
            >
              {isLoading ? (
                <span>Memproses Verifikasi...</span>
              ) : (
                <>
                  <span>Masuk ke Sistem Kafe</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Guest Mode Direct Access */}
          <div className="pt-1 space-y-2">
            <div className="relative flex py-1 items-center">
              <div className="flex-grow border-t border-stone-700/60"></div>
              <span className="flex-shrink mx-3 text-[10px] font-bold text-stone-400 uppercase tracking-widest">
                Atau Mode Pelanggan
              </span>
              <div className="flex-grow border-t border-stone-700/60"></div>
            </div>

            <button
              type="button"
              onClick={() => handleQuickDemoLogin('GUEST', 'Tamu Café (Buku Menu)')}
              className="w-full py-2.5 px-3 rounded-2xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/40 text-amber-300 font-extrabold text-xs flex items-center justify-center gap-2 transition active:scale-[0.99] cursor-pointer"
            >
              <Coffee className="w-4 h-4 text-amber-400" />
              <span>Buka Menu Digital sebagai Tamu (Walk-In)</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Notice: Tenant Isolation & Registration */}
          <div className="pt-1 text-center space-y-1">
            <p className="text-[11px] text-stone-400 font-medium">
              Akun yang didaftarkan Owner (Staf/Manager/Co-Owner) otomatis terisolasi ke café tempat mereka terdaftar saat login.
            </p>
            <p className="text-[10px] text-stone-500">
              Registrasi staf baru dilakukan di konsol Owner menu Staf & Absensi.
            </p>
          </div>
        </div>

        {/* Dedicated Quick Demo Account Switcher Section (HANYA DI HALAMAN LOGIN) */}
        <div className="w-full max-w-4xl mt-10 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-stone-800 pb-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <h3 className="font-extrabold text-sm sm:text-base text-white">
                Akses Cepat Akun Demo (Uji Coba Multi-Peran)
              </h3>
            </div>
            <p className="text-[11px] text-stone-400">
              Pilih peran di bawah untuk login instan dengan hak akses & permission terisolasi
            </p>
          </div>

          {/* Grid of Demo Accounts */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {demoAccounts.map((account) => {
              const Icon = account.icon;
              return (
                <button
                  key={account.role}
                  type="button"
                  onClick={() => handleQuickDemoLogin(account.role, account.title)}
                  disabled={isLoading}
                  className="bg-[#262523] hover:bg-[#312F2C] border border-stone-800 hover:border-amber-600/60 rounded-2xl p-4 text-left transition flex flex-col justify-between group active:scale-[0.98] cursor-pointer shadow-md"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-1.5">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center group-hover:bg-amber-500 group-hover:text-stone-950 transition">
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${account.badgeColor}`}>
                        {account.badge}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-bold text-xs sm:text-sm text-white group-hover:text-amber-300 transition">
                        {account.title}
                      </h4>
                      <p className="text-[11px] text-stone-300 font-semibold truncate">
                        {account.name}
                      </p>
                      <p className="text-[10px] text-stone-500 font-mono truncate">
                        {account.email}
                      </p>
                    </div>

                    <p className="text-[10px] text-stone-400 leading-relaxed line-clamp-3">
                      {account.desc}
                    </p>
                  </div>

                  {account.note && (
                    <div className="mt-3 pt-2 border-t border-stone-800 flex items-center gap-1 text-[9px] font-bold text-emerald-400">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      <span>{account.note}</span>
                    </div>
                  )}

                  <div className="mt-3 text-right">
                    <span className="text-[10px] font-extrabold text-amber-400 group-hover:underline flex items-center justify-end gap-1">
                      <span>Masuk Akun</span>
                      <ArrowRight className="w-3 h-3" />
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 border-t border-stone-800/80 py-4 text-center text-[11px] text-stone-500">
        KOPIIN Point of Sale &bull; Arsitektur Multi-Tenant Terisolasi &bull; Desain Native Android
      </footer>
    </div>
  );
};
